package at.petrak.hexcasting.api.addldata;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_3218;

public interface ADHexHolder {

    boolean canDrawMediaFromInventory();

    boolean hasHex();

    @Nullable
    List<Iota> getHex(class_3218 level);

    void writeHex(List<Iota> patterns, @Nullable FrozenPigment pigment, long media);

    void clearHex();

    @Nullable FrozenPigment getPigment();
}
