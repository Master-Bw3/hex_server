package at.petrak.hexcasting.api.mod;

import at.petrak.hexcasting.api.misc.MediaConstants;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexStatistics {
    public static final class_2960 MEDIA_USED = makeCustomStat("media_used",
        mediamount -> class_3446.field_16975.format((int) (mediamount / MediaConstants.DUST_UNIT)));
    public static final class_2960 MEDIA_OVERCAST = makeCustomStat("media_overcast",
        mediamount -> class_3446.field_16975.format((int) (mediamount / MediaConstants.DUST_UNIT)));
    public static final class_2960 PATTERNS_DRAWN = makeCustomStat("patterns_drawn", class_3446.field_16975);
    public static final class_2960 SPELLS_CAST = makeCustomStat("spells_cast", class_3446.field_16975);

    public static void register() {
        // wake up java
    }

    private static class_2960 makeCustomStat(String key, class_3446 formatter) {
        class_2960 resourcelocation = modLoc(key);
        class_2378.method_10226(class_7923.field_41183, key, resourcelocation);
        class_3468.field_15419.method_14955(resourcelocation, formatter);
        return resourcelocation;
    }
}
