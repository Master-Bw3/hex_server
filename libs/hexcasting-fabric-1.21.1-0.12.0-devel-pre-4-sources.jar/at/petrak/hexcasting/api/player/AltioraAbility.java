package at.petrak.hexcasting.api.player;

import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Note that this just keeps track of state, actually giving the player the elytra ability is handled
 * differently per platform
 *
 * @param gracePeriod so the flight isn't immediately removed because the player started on the ground
 */
public record AltioraAbility(int gracePeriod) {
    public static final class_9139<class_9129, AltioraAbility> STREAM_CODEC = class_9135.field_48550.method_56432(
            AltioraAbility::new,
            AltioraAbility::gracePeriod
    ).method_56439(b -> b);
}
