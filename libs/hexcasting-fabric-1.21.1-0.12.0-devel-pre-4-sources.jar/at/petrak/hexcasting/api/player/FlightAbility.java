package at.petrak.hexcasting.api.player;

import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_5321;

/**
 * @param timeLeft sentinel of -1 for infinite
 * @param radius   sentinel of negative for infinite
 */
public record FlightAbility(int timeLeft, class_5321<class_1937> dimension, class_243 origin, double radius) {
}
