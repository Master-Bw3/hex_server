package at.petrak.hexcasting.api.advancements;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class SpendMediaTrigger extends class_4558<SpendMediaTrigger.Instance> {
    private static final class_2960 ID = class_2960.method_60655("hexcasting", "spend_media");

    @Override
    public Codec<Instance> method_54937() {
        return Instance.CODEC;
    }

    public void trigger(class_3222 player, long mediaSpent, long mediaWasted) {
        super.method_22510(player, inst -> inst.test(mediaSpent, mediaWasted));
    }

    public static record Instance(
            Optional<class_5258> player,
            MinMaxLongs mediaSpent,
            MinMaxLongs mediaWasted
    ) implements class_4558.class_8788 {
        public static final Codec<Instance> CODEC = RecordCodecBuilder.create(
                inst -> inst.group(
                                class_2048.field_47250.optionalFieldOf("player").forGetter(Instance::comp_2029),
                                MinMaxLongs.CODEC.fieldOf("media_generated").forGetter(Instance::mediaSpent),
                                MinMaxLongs.CODEC.fieldOf("health_used").forGetter(Instance::mediaWasted)
                        )
                        .apply(inst, Instance::new)
        );

        private boolean test(long mediaSpentIn, long mediaWastedIn) {
            return this.mediaSpent.matches(mediaSpentIn) && this.mediaWasted.matches(mediaWastedIn);
        }

        @Override
        public Optional<class_5258> comp_2029() {
            return Optional.empty();
        }
    }
}
