package at.petrak.hexcasting.api.casting.eval.env;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.advancements.HexAdvancementTriggers;
import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.eval.CastResult;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.eval.MishapEnvironment;
import at.petrak.hexcasting.api.casting.eval.sideeffects.OperatorSideEffect;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.api.mod.HexStatistics;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.utils.MediaHelper;
import at.petrak.hexcasting.common.lib.HexAttributes;
import at.petrak.hexcasting.common.lib.HexDamageTypes;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3532;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public abstract class PlayerBasedCastEnv extends CastingEnvironment {
    public static final double DEFAULT_AMBIT_RADIUS = 32.0;
    private double ambitRadius;
    public static final double DEFAULT_SENTINEL_RADIUS = 16.0;
    private double sentinelRadius;

    protected final class_3222 caster;
    protected final class_1268 castingHand;

    protected PlayerBasedCastEnv(class_3222 caster, class_1268 castingHand) {
        super(caster.method_51469());
        this.caster = caster;
        this.castingHand = castingHand;
        this.ambitRadius = caster.method_45325(HexAttributes.AMBIT_RADIUS);
        this.sentinelRadius = caster.method_45325(HexAttributes.SENTINEL_RADIUS);
    }

    @Override
    public class_1309 getCastingEntity() {
        return this.caster;
    }

    @Override
    public class_3222 getCaster() {
        return this.caster;
    }

    @Override
    public void postExecution(CastResult result) {
        super.postExecution(result);

        for (var sideEffect : result.getSideEffects()) {
            if (sideEffect instanceof OperatorSideEffect.DoMishap doMishap) {
                this.sendMishapMsgToPlayer(doMishap);
            }
        }
        if (this.caster != null){
            double ambitAttribute = this.caster.method_45325(HexAttributes.AMBIT_RADIUS);
            if (this.ambitRadius != ambitAttribute){
                this.ambitRadius = ambitAttribute;
            }
            double sentinelAttribute = this.caster.method_45325(HexAttributes.SENTINEL_RADIUS);
            if (this.sentinelRadius != sentinelAttribute){
                this.sentinelRadius = sentinelAttribute;
            }
        }
    }

    @Override
    protected List<class_1799> getUsableStacks(StackDiscoveryMode mode) {
        return getUsableStacksForPlayer(mode, castingHand, caster);
    }

    @Override
    protected List<HeldItemInfo> getPrimaryStacks() {
        return getPrimaryStacksForPlayer(this.castingHand, this.caster);
    }

    public double getAmbitRadius() {
        return this.ambitRadius;
    }

    public double getSentinelRadius(){
        return this.sentinelRadius;
    }

    @Override
    public boolean replaceItem(Predicate<class_1799> stackOk, class_1799 replaceWith, @Nullable class_1268 hand) {
        return replaceItemForPlayer(stackOk, replaceWith, hand, this.caster);
    }

    @Override
    public boolean isVecInRangeEnvironment(class_243 vec) {
        var sentinel = HexAPI.instance().getSentinel(this.caster);
        if (sentinel != null
            && sentinel.extendsRange()
            && this.caster.method_37908().method_27983() == sentinel.dimension()
                // adding 0.00000000001 to avoid machine precision errors at specific angles
                && vec.method_1025(sentinel.position()) <= sentinelRadius * sentinelRadius + 0.00000000001
        ) {
            return true;
        }

        return vec.method_1025(this.caster.method_19538()) <= ambitRadius * ambitRadius + 0.00000000001;
    }

    @Override
    public boolean hasEditPermissionsAtEnvironment(class_2338 pos) {
        return this.caster.field_13974.method_14257() != class_1934.field_9216 && this.world.method_8505(this.caster, pos);
    }

    /**
     * Search the player's inventory for media ADs and use them.
     */
    protected long extractMediaFromInventory(long costLeft, boolean allowOvercast, boolean simulate) {
        List<ADMediaHolder> sources = MediaHelper.scanPlayerForMediaStuff(this.caster);

        var startCost = costLeft;

        for (var source : sources) {
            var found = MediaHelper.extractMedia(source, costLeft, false, simulate);
            costLeft -= found;
            if (costLeft <= 0) {
                break;
            }
        }

        if (costLeft > 0 && allowOvercast) {
            double mediaToHealth = HexConfig.common().mediaToHealthRate();
            double healthToRemove = Math.max(costLeft / mediaToHealth, 0.5);
            if (simulate) {
                long simulatedRemovedMedia = class_3532.method_15384(Math.min(this.caster.method_6032(), healthToRemove) * mediaToHealth);
                if (this.caster.method_5679(this.caster.method_48923().method_48795(HexDamageTypes.OVERCAST))) {
                    simulatedRemovedMedia = 0;
                }
                costLeft -= simulatedRemovedMedia;
            } else {
                var mediaAbleToCastFromHP = this.caster.method_6032() * mediaToHealth;

                Mishap.trulyHurt(this.caster, this.world.method_48963().method_48795(HexDamageTypes.OVERCAST), (float) healthToRemove);

                var actuallyTaken = class_3532.method_15384(mediaAbleToCastFromHP - (this.caster.method_6032() * mediaToHealth));

                HexAdvancementTriggers.OVERCAST_TRIGGER.trigger(this.caster, actuallyTaken);
                this.caster.method_7339(HexStatistics.MEDIA_OVERCAST, actuallyTaken);

                costLeft -= actuallyTaken;
            }
        }

        if (!simulate) {
            this.caster.method_7339(HexStatistics.MEDIA_USED, (int) (startCost - costLeft));
            HexAdvancementTriggers.SPEND_MEDIA_TRIGGER.trigger(
                    this.caster,
                    startCost - costLeft,
                    costLeft < 0 ? -costLeft : 0
            );
        }

        return costLeft;
    }

    protected boolean canOvercast() {
        var adv = this.world.method_8503().method_3851().method_12896(modLoc("y_u_no_cast_angy"));
        if(adv != null) {
            var advs = this.caster.method_14236();
            return advs.method_12882(adv).method_740();
        }
        return false;
    }

    @Override
    public @Nullable FrozenPigment setPigment(@Nullable FrozenPigment pigment) {
        return IXplatAbstractions.INSTANCE.setPigment(caster, pigment);
    }

    @Override
    public void produceParticles(ParticleSpray particles, FrozenPigment pigment) {
        particles.sprayParticles(this.world, pigment);
    }

    @Override
    public class_243 mishapSprayPos() {
        return this.caster.method_19538();
    }

    @Override
    public MishapEnvironment getMishapEnvironment() {
        return new PlayerBasedMishapEnv(this.caster);
    }

    protected void sendMishapMsgToPlayer(OperatorSideEffect.DoMishap mishap) {
        var msg = mishap.getMishap().errorMessageWithName(this, mishap.getErrorCtx());
        if (msg != null) {
            this.caster.method_43496(msg);
        }
    }

    @Override
    protected boolean isCreativeMode() {
        // not sure what the diff between this and isCreative() is
        return this.caster.method_31549().field_7477;
    }

    @Override
    public void printMessage(class_2561 message) {
        caster.method_43496(message);
    }
}
