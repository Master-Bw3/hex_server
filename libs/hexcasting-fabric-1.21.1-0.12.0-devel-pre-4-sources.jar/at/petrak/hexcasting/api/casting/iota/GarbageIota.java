package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * this is LITERALLY a copy of NullIota but I can't see how to do it any better, i hate java generics
 */
public class GarbageIota extends Iota {
    private static final Object NULL_SUBSTITUTE = new Object();

    public static final class_2561 DISPLAY = class_2561.method_43470("arimfexendrapuse")
        .method_27695(class_124.field_1063, class_124.field_1051);

    public GarbageIota() {
        // We have to pass *something* here, but there's nothing that actually needs to go there,
        // so we just do this i guess
        super(() -> HexIotaTypes.GARBAGE);
    }

    @Override
    public boolean isTruthy() {
        return false;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that);
    }

    @Override
    public int hashCode() {
        return NULL_SUBSTITUTE.hashCode();
    }

    @Override
    public class_2561 display() {
        return DISPLAY;
    }

    public static IotaType<GarbageIota> TYPE = new IotaType<>() {
        public static final MapCodec<GarbageIota> CODEC = MapCodec.unit(new GarbageIota());
        public static final class_9139<class_9129, GarbageIota> STREAM_CODEC =
                class_9139.method_56431(new GarbageIota());

        @Override
        public MapCodec<GarbageIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, GarbageIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_505050;
        }
    };
}
