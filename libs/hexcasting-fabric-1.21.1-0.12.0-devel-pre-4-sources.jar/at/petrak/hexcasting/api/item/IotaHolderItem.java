package at.petrak.hexcasting.api.item;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_3532;

/**
 * Items that store an iota to their tag can implement this interface.
 * <p>
 * On both the Forge and Fabric sides, the registry will be scanned for all items which implement this interface,
 * and the appropriate cap/CC will be attached.
 */
public interface IotaHolderItem {

    @Nullable
    default Iota readIota(class_1799 stack) {
        if (!(stack.method_7909() instanceof IotaHolderItem)) {
            // this should be checked via mishap beforehand
            throw new IllegalArgumentException("stack's item must be an IotaHolderItem but was " + stack.method_7909());
        }

        return stack.method_57824(HexDataComponents.IOTA_HOLDER_IOTA);
    }

    /**
     * What is this considered to contain when nothing can be read?
     */
    @Nullable
    default Iota emptyIota(class_1799 stack) {
        return null;
    }

    default int getColor(class_1799 stack) {
        var override = stack.method_57824(HexDataComponents.VISUAL_OVERRIDE);
        //noinspection OptionalAssignedToNull
        if (override != null) {
            return override.map(IotaType::color).orElseGet(() -> 0xFF000000 | class_3532.method_15369(ClientTickCounter.getTotal() * 2 % 360 / 360F, 0.75F, 1F));
        }

        var iota = this.readIota(stack);
        if (iota == null) {
            return HexUtils.ERROR_COLOR;
        }

        return iota.getType().color();
    }

    /**
     * @return whether it is possible to write to this IotaHolder
     */
    boolean writeable(class_1799 stack);

    /**
     * Write {@code null} to indicate erasing
     */
    boolean canWrite(class_1799 stack, @Nullable Iota iota);

    /**
     * Write {@code null} to indicate erasing
     */
    void writeDatum(class_1799 stack, @Nullable Iota iota);

    static void appendHoverText(IotaHolderItem self, class_1799 stack, List<class_2561> components,
        class_1836 flag) {
        var datum = self.readIota(stack);
        if (datum != null) {
            var cmp = datum.display();
            components.add(class_2561.method_43469("hexcasting.spelldata.onitem", cmp));

            //TODO port: show NBT in advanced display
            /*if (flag.isAdvanced()) {
                components.add(Component.literal("").append(NbtUtils.toPrettyComponent(datum)));
            }*/
        } else if (stack.method_57826(HexDataComponents.VISUAL_OVERRIDE)) {
            components.add(class_2561.method_43469("hexcasting.spelldata.onitem",
                class_2561.method_43471("hexcasting.spelldata.anything").method_27692(class_124.field_1076)));
        }
    }
}
