package at.petrak.hexcasting.api.block;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public abstract class HexBlockEntity extends class_2586 {
    public HexBlockEntity(class_2591<?> pType, class_2338 pWorldPosition, class_2680 pBlockState) {
        super(pType, pWorldPosition, pBlockState);
    }

    protected abstract void saveModData(class_2487 tag, class_7225.class_7874 registries);

    protected abstract void loadModData(class_2487 tag, class_7225.class_7874 registries);

    @Override
    protected void method_11007(class_2487 pTag, class_7225.class_7874 registries) {
        super.method_11007(pTag, registries);
        this.saveModData(pTag, registries);
    }

    @Override
    public void method_11014(class_2487 pTag, class_7225.class_7874 registries) {
        super.method_11014(pTag, registries);
        this.loadModData(pTag, registries);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = new class_2487();
        this.saveModData(tag, registries);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    public void sync() {
        this.method_5431();
        this.field_11863.method_8413(this.method_11016(), this.method_11010(), this.method_11010(), 3);
    }

}
