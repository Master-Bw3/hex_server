package at.petrak.hexcasting.api.pigment;

import at.petrak.hexcasting.api.addldata.ADPigment;
import net.minecraft.class_243;
import net.minecraft.class_5253;

public abstract class ColorProvider {
    /**
     * Implers, impl this function
     */
    protected abstract int getRawColor(float time, class_243 position);

    private static final int[] MINIMUM_LUMINANCE_COLOR_WHEEL = {
        0xFF200000, 0xFF202000, 0xFF002000, 0xFF002020, 0xFF000020, 0xFF200020
    };

    /**
     * Gets a color with a minimum luminance applied.
     *
     * @param time     absolute world time in ticks
     * @param position a position for the icosahedron, a randomish number for particles.
     * @return an AARRGGBB color.
     */
    public final int getColor(float time, class_243 position) {
        int raw = this.getRawColor(time, position);

        var r = class_5253.class_5254.method_27765(raw);
        var g = class_5253.class_5254.method_27766(raw);
        var b = class_5253.class_5254.method_27767(raw);
        double luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 0xFF; // Standard relative luminance calculation

        if (luminance < 0.05) {
            int rawMod = ADPigment.morphBetweenColors(MINIMUM_LUMINANCE_COLOR_WHEEL, new class_243(0.1, 0.1, 0.1),
                time / 20 / 20, position);

            r += class_5253.class_5254.method_27765(rawMod);
            g += class_5253.class_5254.method_27766(rawMod);
            b += class_5253.class_5254.method_27767(rawMod);
        }

        return 0xff_000000 | (r << 16) | (g << 8) | b;
    }

    public static final ColorProvider MISSING = new ColorProvider() {
        @Override
        protected int getRawColor(float time, class_243 position) {
            return 0xFF_ff00dc;
        }
    };
}
