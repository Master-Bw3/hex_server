package at.petrak.hexcasting.fabric.recipe;

import at.petrak.hexcasting.api.utils.NBTHelper;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.List;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class FabricUnsealedIngredient extends class_1856 implements CustomIngredient {
    public static final class_2960 ID = modLoc("unsealed");

    private final class_1799 stack;

    public static final MapCodec<FabricUnsealedIngredient> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_1799.field_24671.fieldOf("item").forGetter(FabricUnsealedIngredient::getStack)
    ).apply(instance, FabricUnsealedIngredient::new));

    public static final class_9139<class_9129, FabricUnsealedIngredient> STREAM_CODEC = class_9139.method_56435(
            class_2960.field_48267, FabricUnsealedIngredient::getId,
            class_1799.field_48349, FabricUnsealedIngredient::getStack,
            (a, b) -> new FabricUnsealedIngredient(b)
    );

    private static class_1799 createStack(class_1799 base) {
        class_1799 newStack = base.method_7972();
        class_2487 tag = newStack.method_57824(class_9334.field_49628).method_57461();
        NBTHelper.putString(tag, "VisualOverride", "any");
        newStack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        return newStack;
    }

    protected FabricUnsealedIngredient(class_1799 stack) {
        super(Arrays.stream(class_1856.method_8101(stack).field_9019));
        this.stack = stack;
    }

    public class_1799 getStack() {
        return stack;
    }

    public class_2960 getId() {
        return ID;
    }

    /**
     * Creates a new ingredient matching the given stack
     */
    public static FabricUnsealedIngredient of(class_1799 stack) {
        return new FabricUnsealedIngredient(stack);
    }

    @Override
    public boolean method_8093(@Nullable class_1799 input) {
        if (input == null) {
            return false;
        }

        return false;
    }

    @Override
    public List<class_1799> getMatchingStacks() {
        return List.of(stack);
    }

    @Override
    public boolean requiresTesting() {
        return false;
    }

    @Override
    public CustomIngredientSerializer getSerializer() {
        return Serializer.INSTANCE;
    }

    public static class Serializer implements CustomIngredientSerializer {
        public static final Serializer INSTANCE = new Serializer();

        @Override
        public class_2960 getIdentifier() {
            return FabricUnsealedIngredient.ID;
        }

        @Override
        public MapCodec getCodec(boolean b) {
            return CODEC;
        }

        @Override
        public class_9139 getPacketCodec() {
            return STREAM_CODEC;
        }
    }
}
