package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.common.lib.HexItems;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public class FabricItemEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void tick(CallbackInfo ci) {
        class_1542 entity = (class_1542) (Object) this;
        if (entity.method_6983().method_31574(HexItems.SLATE) && HexItems.SLATE.onEntityItemUpdate(entity.method_6983(), entity))
            ci.cancel();
    }
}
