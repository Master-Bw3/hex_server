package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.common.items.ItemJewelerHammer;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class)
public class FabricBlockBehaviorMixin {
    @Inject(method = "getDestroyProgress", at = @At("HEAD"), cancellable = true)
    private void destroyProgress(class_2680 blockState, class_1657 player, class_1922 blockGetter, class_2338 blockPos,
        CallbackInfoReturnable<Float> cir) {
        if (ItemJewelerHammer.shouldFailToBreak(player, blockState, blockPos)) {
            cir.setReturnValue(0F);
        }
    }
}
