package at.petrak.hexcasting.fabric.mixin.client;

import at.petrak.hexcasting.fabric.xplat.FabricClientXplatImpl;
import net.minecraft.class_243;
import net.minecraft.class_3695;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_761.class)
public class FabricLevelRendererMixin {
    @SuppressWarnings("InvalidInjectorMethodSignature")
    @Inject(
        method = "renderLevel",
        at = @At(
            value = "INVOKE", target = "Lnet/minecraft/client/renderer/FogRenderer;levelFogColor()V",
            ordinal = 0),
        locals = LocalCapture.CAPTURE_FAILSOFT)
    private void snagFrustumFromLevelRenderer(class_4587 poseStack, float f, long arg2, boolean bl, class_4184 camera,
          class_757 gameRenderer, class_765 lightTexture, Matrix4f matrix4f, CallbackInfo ci,
          class_3695 profilerFiller, boolean bl2, class_243 vec3, double d, double e, double g, Matrix4f matrix4f2,
          boolean bl3, class_4604 frustum) {
        FabricClientXplatImpl.LEVEL_RENDERER_FRUSTUM = frustum;
    }
}
