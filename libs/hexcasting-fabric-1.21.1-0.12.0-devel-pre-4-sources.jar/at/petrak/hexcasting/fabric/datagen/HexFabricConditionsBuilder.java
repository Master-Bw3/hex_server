package at.petrak.hexcasting.fabric.datagen;

import at.petrak.hexcasting.datagen.IXplatConditionsBuilder;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceCondition;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.fabricmc.fabric.impl.datagen.FabricDataGenHelper;
import net.minecraft.class_161;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class HexFabricConditionsBuilder implements IXplatConditionsBuilder {
    private final List<ResourceCondition> conditions = new ArrayList<>();
    private final class_5797 parent;

    public HexFabricConditionsBuilder(class_5797 parent) {
        this.parent = parent;
    }

    @Override
    public IXplatConditionsBuilder whenModLoaded(String modid) {
        conditions.add(ResourceConditions.allModsLoaded(modid));
        return this;
    }

    @Override
    public IXplatConditionsBuilder whenModMissing(String modid) {
        conditions.add(ResourceConditions.not(ResourceConditions.allModsLoaded(modid)));
        return this;
    }

    @Override
    public class_5797 method_33530(@NotNull String string, @NotNull class_175 criterionTriggerInstance) {
        return parent.method_33530(string, criterionTriggerInstance);
    }

    @Override
    public class_5797 method_33529(@Nullable String string) {
        return parent.method_33529(string);
    }

    @Override
    public class_1792 method_36441() {
        return parent.method_36441();
    }

    @Override
    @SuppressWarnings("UnstableApiUsage")
    public void method_17972(@NotNull class_8790 consumer, @NotNull class_2960 resourceLocation) {
        ResourceCondition[] array = conditions.toArray(ResourceCondition[]::new);

        class_8790 withConditions = new class_8790() {
            @Override
            public void method_53819(class_2960 resourceLocation, class_1860<?> recipe, @Nullable class_8779 advancementHolder) {
                FabricDataGenHelper.addConditions(consumer, array);
                consumer.method_53819(resourceLocation, recipe, advancementHolder);
            }

            @Override
            public class_161.class_162 method_53818() {
                return consumer.method_53818();
            }
        };

        parent.method_17972(withConditions, resourceLocation);
    }
}
