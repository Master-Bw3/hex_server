package at.petrak.hexcasting.fabric.xplat;

import at.petrak.hexcasting.api.client.ClientCastingStack;
import at.petrak.hexcasting.fabric.cc.HexCardinalComponents;
import at.petrak.hexcasting.fabric.client.ExtendedTexture;
import at.petrak.hexcasting.fabric.interop.accessories.AccessoriesApiInterop;
import at.petrak.hexcasting.interop.HexInterop;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1044;
import net.minecraft.class_1091;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5272;
import net.minecraft.class_5617;
import net.minecraft.class_638;
import net.minecraft.class_6395;
import net.minecraft.class_8710;
import org.jetbrains.annotations.Nullable;

public class FabricClientXplatImpl implements IClientXplatAbstractions {
    @Override
    public void sendPacketToServer(class_8710 packet) {
        ClientPlayNetworking.send(packet);
    }

    @Override
    public void setRenderLayer(class_2248 block, class_1921 type) {
        BlockRenderLayerMap.INSTANCE.putBlock(block, type);
    }

    @Override
    public void initPlatformSpecific() {
        if (IXplatAbstractions.INSTANCE.isModPresent(HexInterop.Fabric.ACCESSORIES_API_ID)) {
            AccessoriesApiInterop.clientInit();
        }
    }

    @Override
    public <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> type,
        class_5617<T> renderer) {
        EntityRendererRegistry.register(type, renderer);
    }

    // suck it fabric trying to be "safe"
    private record UnclampedClampedItemPropFunc(class_1800 inner) implements class_6395 {
        @Override
        public float unclampedCall(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity,
            int seed) {
            return inner.call(stack, level, entity, seed);
        }

        @Override
        public float call(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            return this.unclampedCall(stack, level, entity, seed);
        }
    }

    @Override
    public void registerItemProperty(class_1792 item, class_2960 id, class_1800 func) {
        class_5272.method_27879(item, id, new UnclampedClampedItemPropFunc(func));
    }

    @Override
    public ClientCastingStack getClientCastingStack(class_1657 player) {
        return HexCardinalComponents.CLIENT_CASTING_STACK.get(player).getClientCastingStack();
    }

    @Override
    public void setFilterSave(class_1044 texture, boolean filter, boolean mipmap) {
        ((ExtendedTexture) texture).setFilterSave(filter, mipmap);
    }

    @Override
    public void restoreLastFilter(class_1044 texture) {
        ((ExtendedTexture) texture).restoreLastFilter();
    }

    // Set by FabricLevelRendererMixin
    public static class_4604 LEVEL_RENDERER_FRUSTUM = null;

    @Override
    public boolean fabricAdditionalQuenchFrustumCheck(class_238 aabb) {
        if (LEVEL_RENDERER_FRUSTUM == null) {
            return true; // fail safe
        }
        return LEVEL_RENDERER_FRUSTUM.method_23093(aabb);
    }

    @Override
    public String getModelLocVariant() {
        return class_1091.field_52277;
    }
}
