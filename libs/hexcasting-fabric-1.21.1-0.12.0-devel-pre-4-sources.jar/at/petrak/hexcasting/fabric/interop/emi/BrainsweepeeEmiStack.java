package at.petrak.hexcasting.fabric.interop.emi;

import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredient;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.emi.emi.api.stack.EmiStack;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_638;
import net.minecraft.class_9326;

import static at.petrak.hexcasting.api.HexAPI.modLoc;
import static at.petrak.hexcasting.client.render.RenderLib.renderEntity;

public class BrainsweepeeEmiStack extends EmiStack {
    public final BrainsweepeeIngredient ingredient;
    private final class_2960 id;
    private final class_9326 componentChanges;

    public BrainsweepeeEmiStack(BrainsweepeeIngredient ingr) {
        this(ingr, class_9326.field_49588);
    }

    public BrainsweepeeEmiStack(BrainsweepeeIngredient ingr, class_9326 patches) {
        this.ingredient = ingr;
        this.id = modLoc(this.ingredient.getSomeKindOfReasonableIDForEmi());
        this.componentChanges = patches;
    }

    @Override
    public EmiStack copy() {
        return new BrainsweepeeEmiStack(this.ingredient);
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public class_9326 getComponentChanges() {
        return componentChanges;
    }

    @Override
    public Object getKey() {
        return id;
    }

    @Override
    public class_2960 getId() {
        return id;
    }

    @Override
    public List<class_2561> getTooltipText() {
        class_310 mc = class_310.method_1551();
        boolean advanced = mc.field_1690.field_1827;

        return ingredient.getTooltip(advanced);
    }

    @Override
    public List<class_5684> getTooltip() {
        return getTooltipText().stream()
            .map(class_2561::method_30937)
            .map(class_5684::method_32662)
            .collect(Collectors.toList());
    }

    @Override
    public class_2561 getName() {
        return ingredient.getName();
    }

    @Override
    public void render(class_332 graphics, int x, int y, float delta, int flags) {
        if ((flags & RENDER_ICON) != 0) {
            class_310 mc = class_310.method_1551();
            class_638 level = mc.field_1687;
            if (level != null) {
                var example = this.ingredient.exampleEntity(level);

                RenderSystem.enableBlend();
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                renderEntity(graphics, example, level, x + 8, y + 16, ClientTickCounter.getTotal(), 8, 0, it -> it);
            }
        }

//		if ((flags & RENDER_REMAINDER) != 0) {
//			EmiRender.renderRemainderIcon(this, poseStack, x, y);
//		}
    }
}
