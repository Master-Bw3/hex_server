package at.petrak.hexcasting.fabric.cc;

import at.petrak.hexcasting.api.client.ClientCastingStack;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.ladysnake.cca.api.v3.component.Component;
import org.ladysnake.cca.api.v3.component.tick.ClientTickingComponent;

public class CCClientCastingStack implements Component, ClientTickingComponent {

    public CCClientCastingStack(class_1657 owner) {
    }

    private final ClientCastingStack clientCastingStack = new ClientCastingStack();

    public ClientCastingStack getClientCastingStack() {
        return clientCastingStack;
    }

    @Override
    public void clientTick() {
        clientCastingStack.tick();
    }

    @Override
    public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) { }

    @Override
    public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) { }
}
