package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.item.MediaHolderItem;
import org.ladysnake.cca.api.v3.component.Component;

import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public abstract class CCMediaHolder implements ADMediaHolder, Component {
    final class_1799 stack;
    public CCMediaHolder(class_1799 stack) {
        this.stack = stack;
    }

    public static class ItemBased extends CCMediaHolder {
        private final MediaHolderItem mediaHolder;

        public ItemBased(class_1799 stack) {
            super(stack);
            if (!(stack.method_7909() instanceof MediaHolderItem media)) {
                throw new IllegalStateException("item is not a media holder: " + stack);
            }
            this.mediaHolder = media;
        }

        @Override
        public long getMedia() {
            return this.mediaHolder.getMedia(this.stack);
        }

        @Override
        public long getMaxMedia() {
            return this.mediaHolder.getMaxMedia(this.stack);
        }

        @Override
        public void setMedia(long media) {
            this.mediaHolder.setMedia(this.stack, media);
        }

        @Override
        public boolean canRecharge() {
            return this.mediaHolder.canRecharge(this.stack);
        }

        @Override
        public boolean canProvide() {
            return this.mediaHolder.canProvideMedia(this.stack);
        }

        @Override
        public int getConsumptionPriority() {
            return this.mediaHolder.getConsumptionPriority(this.stack);
        }

        @Override
        public boolean canConstructBattery() {
            return false;
        }

        @Override
        public long withdrawMedia(long cost, boolean simulate) {
            return this.mediaHolder.withdrawMedia(this.stack, cost, simulate);
        }

        @Override
        public long insertMedia(long amount, boolean simulate) {
            return this.mediaHolder.insertMedia(this.stack, amount, simulate);
        }

        @Override
        public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }

        @Override
        public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }
    }

    public static class Static extends CCMediaHolder {
        private final Supplier<Long> baseWorth;
        private final int consumptionPriority;

        public Static(Supplier<Long> baseWorth, int consumptionPriority, class_1799 stack) {
            super(stack);
            this.baseWorth = baseWorth;
            this.consumptionPriority = consumptionPriority;
        }

        @Override
        public long getMedia() {
            return baseWorth.get() * stack.method_7947();
        }

        @Override
        public long getMaxMedia() {
            return getMedia();
        }

        @Override
        public void setMedia(long media) {
            // NO-OP
        }

        @Override
        public boolean canRecharge() {
            return false;
        }

        @Override
        public boolean canProvide() {
            return true;
        }

        @Override
        public int getConsumptionPriority() {
            return consumptionPriority;
        }

        @Override
        public boolean canConstructBattery() {
            return true;
        }

        @Override
        public long withdrawMedia(long cost, boolean simulate) {
            long worth = baseWorth.get();
            if (cost < 0) {
                cost = worth * stack.method_7947();
            }
            double itemsRequired = cost / (double) worth;
            int itemsUsed = Math.min((int) Math.ceil(itemsRequired), stack.method_7947());
            if (!simulate) {
                stack.method_7934(itemsUsed);
            }
            return itemsUsed * worth;
        }

        @Override
        public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }

        @Override
        public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {

        }
    }
}
