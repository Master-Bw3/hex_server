package at.petrak.hexcasting.server;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.math.EulerPathFinder;
import at.petrak.hexcasting.api.casting.math.HexDir;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4284;
import net.minecraft.class_5321;
import net.minecraft.class_7225;

/**
 * Maps angle sigs to resource locations and their preferred start dir so we can look them up in the main registry
 * Save this on the world in case the random algorithm changes.
 */
public class ScrungledPatternsSave extends class_18 {
    public static final String DATA_VERSION = "0.1.0";
    public static final String TAG_SAVED_DATA = "hexcasting.per-world-patterns." + DATA_VERSION;
    private static final String TAG_DIR = "startDir";
    private static final String TAG_KEY = "key";

    /**
     * Maps scrungled signatures to their keys.
     */
    private final Map<String, PerWorldEntry> lookup;

    /**
     * Reverse-maps resource keys to their signature; you can use that in {@code lookup}.
     * <p>
     * This way we can look up things if we know their resource key, for commands and such
     */
    private final Map<class_5321<ActionRegistryEntry>, String> reverseLookup;

    private ScrungledPatternsSave(Map<String, PerWorldEntry> lookup) {
        this.lookup = lookup;
        this.reverseLookup = new HashMap<>();
        this.lookup.forEach((sig, entry) -> {
            this.reverseLookup.put(entry.key, sig);
        });
    }

    @Nullable
    public PerWorldEntry lookup(String signature) {
        return this.lookup.get(signature);
    }

    @Nullable
    public Pair<String, PerWorldEntry> lookupReverse(class_5321<ActionRegistryEntry> key) {
        var sig = this.reverseLookup.get(key);
        if (sig == null) return null;

        return Pair.of(sig, this.lookup.get(sig));
    }

    @Override
    public class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        // We don't save the reverse lookup cause we can reconstruct it when loading.
        this.lookup.forEach((sig, entry) -> {
            var inner = new class_2487();
            inner.method_10567(TAG_DIR, (byte) entry.canonicalStartDir.ordinal());
            inner.method_10582(TAG_KEY, entry.key().method_29177().toString());
            tag.method_10566(sig, inner);
        });
        return tag;
    }

    private static ScrungledPatternsSave load(class_2487 tag, class_7225.class_7874 lookup) {
        var registryKey = IXplatAbstractions.INSTANCE.getActionRegistry().method_30517();

        var map = new HashMap<String, PerWorldEntry>();
        for (var sig : tag.method_10541()) {
            var inner = tag.method_10562(sig);

            var rawDir = inner.method_10571(TAG_DIR);
            var rawKey = inner.method_10558(TAG_KEY);

            var dir = HexDir.values()[rawDir];
            var key = class_5321.method_29179(registryKey, class_2960.method_60654(rawKey));

            map.put(sig, new PerWorldEntry(key, dir));
        }

        return new ScrungledPatternsSave(map);
    }

    public static ScrungledPatternsSave createFromScratch(long seed) {
        var map = new HashMap<String, PerWorldEntry>();

        var registry = IXplatAbstractions.INSTANCE.getActionRegistry();

        // TODO: this version of the code doesn't have overlap protection
        // this means if some hilarious funny person makes a great spell that has the same shape as a normal spell
        // there might be overlap.
        // I'm going to file that under "don't do that"
        // (the number literal phial incident won't happen though because we check for special handlers first now)
        for (var key : registry.method_42021()) {
            var entry = registry.method_29107(key);
            if (HexUtils.isOfTag(registry, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                var scrungledPat = EulerPathFinder.findAltDrawing(entry.prototype(), seed);
                map.put(scrungledPat.anglesSignature(), new PerWorldEntry(key, scrungledPat.getStartDir()));
            }
        }

        var out = new ScrungledPatternsSave(map);
        out.method_80();
        return out;
    }

    public static ScrungledPatternsSave open(class_3218 overworld) {
        return overworld.method_17983().method_17924(
            new class_18.class_8645<>(
                    () -> ScrungledPatternsSave.createFromScratch(overworld.method_8412()),
                    ScrungledPatternsSave::load,
                    class_4284.field_19213
            ),
            TAG_SAVED_DATA);
    }

    public record PerWorldEntry(class_5321<ActionRegistryEntry> key, HexDir canonicalStartDir) {
    }
}
