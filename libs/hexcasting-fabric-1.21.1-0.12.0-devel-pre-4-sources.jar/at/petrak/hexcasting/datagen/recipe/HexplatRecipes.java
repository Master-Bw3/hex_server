package at.petrak.hexcasting.datagen.recipe;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.advancements.HexAdvancementTriggers;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.blocks.decoration.BlockAkashicLog;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.items.pigment.ItemPridePigment;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.recipe.SealThingsRecipe;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.EntityTypeIngredient;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.VillagerIngredient;
import at.petrak.hexcasting.common.lib.HexStateIngredients;
import at.petrak.hexcasting.datagen.HexAdvancements;
import at.petrak.hexcasting.datagen.IXplatConditionsBuilder;
import at.petrak.hexcasting.datagen.IXplatIngredients;
import at.petrak.hexcasting.datagen.recipe.builders.BrainsweepRecipeBuilder;
import at.petrak.hexcasting.datagen.recipe.builders.CreateCrushingRecipeBuilder;
import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightCuttingRecipeBuilder;
import at.petrak.paucal.api.PaucalAPI;
import at.petrak.paucal.api.datagen.PaucalAdvancementSubProvider;
import net.minecraft.class_1299;
import net.minecraft.class_174;
import net.minecraft.class_175;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2246;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2456;
import net.minecraft.class_3417;
import net.minecraft.class_3489;
import net.minecraft.class_3852;
import net.minecraft.class_3981;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_7784;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// TODO: need to do a big refactor of this class cause it's giant and unwieldy, probably as part of #360
public class HexplatRecipes extends class_2446 {
    private final IXplatIngredients ingredients;
    private final Function<class_5797, IXplatConditionsBuilder> conditions;

    private final List<BlockAkashicLog> EDIFIED_LOGS = List.of(
        HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_LOG_AMETHYST,
        HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_LOG_CITRINE,
        HexBlocks.EDIFIED_LOG_PURPLE);

    private final Map<BlockAkashicLog, BlockAkashicLog> EDIFIED_LOG_TO_WOOD = Map.ofEntries(
        Map.entry(HexBlocks.EDIFIED_LOG, HexBlocks.EDIFIED_WOOD),
//      These don't exist, idk if they should
//        Map.entry(HexBlocks.EDIFIED_LOG_AMETHYST, HexBlocks.EDIFIED_WOOD_AMETHYST),
//        Map.entry(HexBlocks.EDIFIED_LOG_AVENTURINE, HexBlocks.EDIFIED_WOOD_AVENTURINE),
//        Map.entry(HexBlocks.EDIFIED_LOG_CITRINE, HexBlocks.EDIFIED_WOOD_CITRINE),
//        Map.entry(HexBlocks.EDIFIED_LOG_PURPLE, HexBlocks.EDIFIED_WOOD_PURPLE),
        Map.entry(HexBlocks.STRIPPED_EDIFIED_LOG, HexBlocks.STRIPPED_EDIFIED_WOOD)
    );

    public HexplatRecipes(class_7784 output, CompletableFuture<class_7225.class_7874> registries, IXplatIngredients ingredients,
                          Function<class_5797, IXplatConditionsBuilder> conditions) {
        super(output, registries);
        this.ingredients = ingredients;
        this.conditions = conditions;
    }

    @Override
    public void method_10419(class_8790 recipes) {
        specialRecipe(recipes, SealThingsRecipe.FOCUS_SERIALIZER, SealThingsRecipe::focus);
        specialRecipe(recipes, SealThingsRecipe.SPELLBOOK_SERIALIZER, SealThingsRecipe::spellbook);

        staffRecipe(recipes, HexItems.STAFF_OAK, class_1802.field_8118);
        staffRecipe(recipes, HexItems.STAFF_BIRCH, class_1802.field_8191);
        staffRecipe(recipes, HexItems.STAFF_SPRUCE, class_1802.field_8113);
        staffRecipe(recipes, HexItems.STAFF_JUNGLE, class_1802.field_8842);
        staffRecipe(recipes, HexItems.STAFF_DARK_OAK, class_1802.field_8404);
        staffRecipe(recipes, HexItems.STAFF_ACACIA, class_1802.field_8651);
        staffRecipe(recipes, HexItems.STAFF_CRIMSON, class_1802.field_22031);
        staffRecipe(recipes, HexItems.STAFF_WARPED, class_1802.field_22032);
        staffRecipe(recipes, HexItems.STAFF_MANGROVE, class_1802.field_37507);
        staffRecipe(recipes, HexItems.STAFF_CHERRY, class_1802.field_42687);
        staffRecipe(recipes, HexItems.STAFF_BAMBOO, class_1802.field_40213);
        staffRecipe(recipes, HexItems.STAFF_EDIFIED, HexBlocks.EDIFIED_PLANKS.method_8389());
        staffRecipe(recipes, HexItems.STAFF_QUENCHED, HexItems.QUENCHED_SHARD);
        staffRecipe(recipes, HexItems.STAFF_MINDSPLICE, class_1856.method_8106(HexTags.Items.MINDFLAYED_CIRCLE_COMPONENTS));

        class_2450.method_10447(class_7800.field_40638, HexItems.THOUGHT_KNOT)
            .method_10454(HexItems.AMETHYST_DUST)
            .method_10454(class_1802.field_8276)
            .method_10442("has_item", hasItem(HexTags.Items.STAVES))
            .method_10431(recipes);
        class_2447.method_10437(class_7800.field_40638, HexItems.FOCUS)
            .method_10428('G', ingredients.glowstoneDust())
            .method_10428('L', ingredients.leather())
            .method_10434('P', class_1802.field_8407)
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            .method_10439("GLG")
            .method_10439("PAP")
            .method_10439("GLG")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES))
            .method_10431(recipes);
        class_2447.method_10437(class_7800.field_40638, HexItems.FOCUS)
            .method_10428('G', ingredients.glowstoneDust())
            .method_10428('L', ingredients.leather())
            .method_10434('P', class_1802.field_8407)
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            .method_10439("GPG")
            .method_10439("LAL")
            .method_10439("GPG")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES))
            .method_17972(recipes, modLoc("focus_rotated"));

        class_2447.method_10437(class_7800.field_40638, HexItems.SPELLBOOK)
            .method_10428('N', ingredients.goldNugget())
            .method_10434('B', class_1802.field_8674)
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            .method_10434('F', class_1802.field_8233) // i wanna gate this behind the end SOMEHOW
            // hey look its my gender ^^
            .method_10439("NBA")
            .method_10439("NFA")
            .method_10439("NBA")
            .method_10429("has_focus", hasItem(HexItems.FOCUS))
            .method_10429("has_chorus", hasItem(class_1802.field_8233)).method_10431(recipes);

        ringCornerless(class_7800.field_40638,
            HexItems.CYPHER, 1,
            ingredients.copperIngot(),
            class_1856.method_8091(HexItems.AMETHYST_DUST))
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        ringCornerless(class_7800.field_40638,
            HexItems.TRINKET, 1,
            ingredients.ironIngot(),
            class_1856.method_8091(class_1802.field_27063))
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40638, HexItems.ARTIFACT)
            .method_10428('F', ingredients.goldIngot())
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            // why in god's name does minecraft have two different places for item tags
            // TODO port: check if good for music discs
            .method_10433('D', class_3489.field_23969)
            .method_10439(" F ")
            .method_10439("FAF")
            .method_10439(" D ")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        ringCornerless(class_7800.field_40638, HexItems.SCRYING_LENS, 1, class_1802.field_8280, HexItems.AMETHYST_DUST)
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40638, HexItems.ABACUS)
            .method_10434('S', class_1802.field_8600)
            .method_10434('A', class_1802.field_27063)
            .method_10433('W', class_3489.field_15537)
            .method_10439("WAW")
            .method_10439("SAS")
            .method_10439("WAW")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        // Why am I like this
        class_2447.method_10437(class_7800.field_40640, HexItems.SUBMARINE_SANDWICH)
            .method_10434('S', class_1802.field_8600)
            .method_10434('A', class_1802.field_27063)
            .method_10434('C', class_1802.field_8176)
            .method_10434('B', class_1802.field_8229)
            .method_10439(" SA")
            .method_10439(" C ")
            .method_10439(" B ")
            .method_10429("has_item", hasItem(class_1802.field_27063)).method_10431(recipes);

        for (var dye : class_1767.values()) {
            var item = HexItems.DYE_PIGMENTS.get(dye);
            class_2447.method_10437(class_7800.field_40642, item)
                .method_10434('D', HexItems.AMETHYST_DUST)
                .method_10434('C', class_1769.method_7803(dye))
                .method_10439(" D ")
                .method_10439("DCD")
                .method_10439(" D ")
                .method_10429("has_item", hasItem(HexItems.AMETHYST_DUST)).method_10431(recipes);
        }

        gayRecipe(recipes, ItemPridePigment.Type.AGENDER, class_1856.method_8091(class_1802.field_8280));
        gayRecipe(recipes, ItemPridePigment.Type.AROACE, class_1856.method_8091(class_1802.field_8317));
        gayRecipe(recipes, ItemPridePigment.Type.AROMANTIC, class_1856.method_8091(class_1802.field_8107));
        gayRecipe(recipes, ItemPridePigment.Type.ASEXUAL, class_1856.method_8091(class_1802.field_8229));
        gayRecipe(recipes, ItemPridePigment.Type.BISEXUAL, class_1856.method_8091(class_1802.field_8861));
        gayRecipe(recipes, ItemPridePigment.Type.DEMIBOY, class_1856.method_8091(class_1802.field_33400));
        gayRecipe(recipes, ItemPridePigment.Type.DEMIGIRL, class_1856.method_8091(class_1802.field_33401));
        gayRecipe(recipes, ItemPridePigment.Type.GAY, class_1856.method_8091(class_1802.field_8337));
        gayRecipe(recipes, ItemPridePigment.Type.GENDERFLUID, class_1856.method_8091(class_1802.field_8705));
        gayRecipe(recipes, ItemPridePigment.Type.GENDERQUEER, class_1856.method_8091(class_1802.field_8469));
        gayRecipe(recipes, ItemPridePigment.Type.INTERSEX, class_1856.method_8091(class_1802.field_28650));
        gayRecipe(recipes, ItemPridePigment.Type.LESBIAN, class_1856.method_8091(class_1802.field_20414));
        gayRecipe(recipes, ItemPridePigment.Type.NONBINARY, class_1856.method_8091(class_1802.field_28654));
        // TODO port: This is neither an item value nor a tag value.
        /*gayRecipe(recipes, ItemPridePigment.Type.PANSEXUAL, ingredients.whenModIngredient(
            Ingredient.of(Items.CARROT),
            "farmersdelight",
            CompatIngredientValue.of("farmersdelight:skillet")
        ));*/
        gayRecipe(recipes, ItemPridePigment.Type.PLURAL, class_1856.method_8091(class_1802.field_8619));
        gayRecipe(recipes, ItemPridePigment.Type.TRANSGENDER, class_1856.method_8091(class_1802.field_8803));

        ring(class_7800.field_40642, HexItems.UUID_PIGMENT, 1, HexItems.AMETHYST_DUST, class_1802.field_27063)
            .method_10429("has_item", hasItem(HexItems.AMETHYST_DUST)).method_10431(recipes);
        ringCornerless(class_7800.field_40642, HexItems.DEFAULT_PIGMENT, 1, HexItems.AMETHYST_DUST, class_1802.field_27063)
            .method_10429("has_item", hasItem(HexItems.AMETHYST_DUST)).method_10431(recipes);
        ringCornerless(class_7800.field_40642, HexItems.ANCIENT_PIGMENT, 1, HexItems.AMETHYST_DUST, class_1802.field_27022)
            .method_10429("has_item", hasItem(HexItems.AMETHYST_DUST)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40635, HexItems.SCROLL_SMOL)
            .method_10434('P', class_1802.field_8407)
            .method_10434('A', HexItems.AMETHYST_DUST)
            .method_10439(" A")
            .method_10439("P ")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40635, HexItems.SCROLL_MEDIUM)
            .method_10434('P', class_1802.field_8407)
            .method_10434('A', HexItems.AMETHYST_DUST)
            .method_10439("  A")
            .method_10439("PP ")
            .method_10439("PP ")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40635, HexItems.SCROLL_LARGE)
            .method_10434('P', class_1802.field_8407)
            .method_10434('A', HexItems.AMETHYST_DUST)
            .method_10439("PPA")
            .method_10439("PPP")
            .method_10439("PPP")
            .method_10429("has_item", hasItem(HexTags.Items.STAVES)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40635, HexItems.SLATE, 6)
            .method_10434('S', class_1802.field_28866)
            .method_10434('A', HexItems.AMETHYST_DUST)
            .method_10439(" A ")
            .method_10439("SSS")
            .method_10429("has_item", hasItem(HexItems.AMETHYST_DUST)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40638, HexItems.JEWELER_HAMMER)
            .method_10428('I', ingredients.ironIngot())
            .method_10428('N', ingredients.ironNugget())
            .method_10434('A', class_1802.field_27063)
            .method_10428('S', ingredients.stick())
            .method_10439("IAN")
            .method_10439(" S ")
            .method_10439(" S ")
            .method_10429("has_item", hasItem(class_1802.field_27063)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40642, HexItems.AMETHYST_DUST,
                (int) (MediaConstants.QUENCHED_SHARD_UNIT / MediaConstants.DUST_UNIT) + 1)
            .method_10454(HexItems.QUENCHED_SHARD)
            .method_10454(HexItems.AMETHYST_DUST)
            .method_10442("has_item", hasItem(HexItems.QUENCHED_SHARD))
            .method_17972(recipes, modLoc("decompose_quenched_shard/dust"));
        class_2450.method_10448(class_7800.field_40642, class_1802.field_27063,
                (int) (MediaConstants.QUENCHED_SHARD_UNIT / MediaConstants.SHARD_UNIT) + 1)
            .method_10454(HexItems.QUENCHED_SHARD)
            .method_10454(class_1802.field_27063)
            .method_10442("has_item", hasItem(HexItems.QUENCHED_SHARD))
            .method_17972(recipes, modLoc("decompose_quenched_shard/shard"));
        class_2450.method_10448(class_7800.field_40642, HexItems.CHARGED_AMETHYST,
                (int) (MediaConstants.QUENCHED_SHARD_UNIT / MediaConstants.CRYSTAL_UNIT) + 1)
            .method_10454(HexItems.QUENCHED_SHARD)
            .method_10454(HexItems.CHARGED_AMETHYST)
            .method_10442("has_item", hasItem(HexItems.QUENCHED_SHARD))
            .method_17972(recipes, modLoc("decompose_quenched_shard/charged"));

        class_2447.method_10437(class_7800.field_40634, HexBlocks.SLATE_BLOCK)
            .method_10434('S', HexItems.SLATE)
            .method_10439("S")
            .method_10439("S")
            .method_10429("has_item", hasItem(HexItems.SLATE))
            .method_17972(recipes, modLoc("slate_block_from_slates"));

        ringAll(class_7800.field_40634, HexBlocks.SLATE_BLOCK, 8, class_2246.field_28888, HexItems.AMETHYST_DUST)
            .method_10429("has_item", hasItem(HexItems.SLATE)).method_10431(recipes);

        packing(class_7800.field_40634, HexItems.AMETHYST_DUST, HexBlocks.AMETHYST_DUST_BLOCK.method_8389(), "amethyst_dust",
            false, recipes);

        ringAll(class_7800.field_40634, HexBlocks.SCROLL_PAPER, 8, class_1802.field_8407, class_1802.field_27063)
            .method_10429("has_item", hasItem(class_1802.field_27063)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40634, HexBlocks.ANCIENT_SCROLL_PAPER, 8)
            .method_10451(ingredients.dyes().get(class_1767.field_7957))
            .method_10449(HexBlocks.SCROLL_PAPER, 8)
            .method_10442("has_item", hasItem(HexBlocks.SCROLL_PAPER)).method_10431(recipes);

        stack(class_7800.field_40635, HexBlocks.SCROLL_PAPER_LANTERN, 1, HexBlocks.SCROLL_PAPER, class_1802.field_8810)
            .method_10429("has_item", hasItem(HexBlocks.SCROLL_PAPER)).method_10431(recipes);

        stack(class_7800.field_40635, HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN, 1, HexBlocks.ANCIENT_SCROLL_PAPER, class_1802.field_8810)
            .method_10429("has_item", hasItem(HexBlocks.ANCIENT_SCROLL_PAPER)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40635, HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN, 8)
            .method_10451(ingredients.dyes().get(class_1767.field_7957))
            .method_10449(HexBlocks.SCROLL_PAPER_LANTERN, 8)
            .method_10442("has_item", hasItem(HexBlocks.SCROLL_PAPER_LANTERN))
            .method_17972(recipes, modLoc("ageing_scroll_paper_lantern"));

        stack(class_7800.field_40635, HexBlocks.SCONCE, 4,
            class_1856.method_8091(HexItems.CHARGED_AMETHYST),
            ingredients.copperIngot())
            .method_10429("has_item", hasItem(HexItems.CHARGED_AMETHYST)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40634, HexBlocks.EDIFIED_PLANKS, 4)
            .method_10446(HexTags.Items.EDIFIED_LOGS)
            .method_10442("has_item", hasItem(HexTags.Items.EDIFIED_LOGS)).method_10431(recipes);

        for (var entry : EDIFIED_LOG_TO_WOOD.entrySet()) {
            var log = entry.getKey();
            var wood = entry.getValue();
            class_2447.method_10436(class_7800.field_40634, wood, 3)
                    .method_10434('W', log)
                    .method_10439("WW")
                    .method_10439("WW")
                    .method_10429("has_item", hasItem(log)).method_10431(recipes);
        }

        ring(class_7800.field_40634, HexBlocks.EDIFIED_PANEL, 8,
            HexTags.Items.EDIFIED_PLANKS, null)
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40634, HexBlocks.EDIFIED_TILE, 6)
            .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
            .method_10439("WW ")
            .method_10439("W W")
            .method_10439(" WW")
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40636, HexBlocks.EDIFIED_DOOR, 3)
            .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
            .method_10439("WW")
            .method_10439("WW")
            .method_10439("WW")
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40636, HexBlocks.EDIFIED_TRAPDOOR, 2)
            .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
            .method_10439("WWW")
            .method_10439("WWW")
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40634, HexBlocks.EDIFIED_STAIRS, 4)
            .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
            .method_10439("W  ")
            .method_10439("WW ")
            .method_10439("WWW")
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40634, HexBlocks.EDIFIED_FENCE, 3)
                .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
                .method_10434('S', class_1802.field_8600)
                .method_10439("WSW")
                .method_10439("WSW")
                .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40634, HexBlocks.EDIFIED_FENCE_GATE, 1)
                .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
                .method_10434('S', class_1802.field_8600)
                .method_10439("SWS")
                .method_10439("SWS")
                .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);


        class_2447.method_10436(class_7800.field_40634, HexBlocks.EDIFIED_SLAB, 6)
            .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
            .method_10439("WWW")
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40636, HexBlocks.EDIFIED_PRESSURE_PLATE, 1)
            .method_10433('W', HexTags.Items.EDIFIED_PLANKS)
            .method_10439("WW")
            .method_10429("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        class_2450.method_10447(class_7800.field_40636, HexBlocks.EDIFIED_BUTTON)
            .method_10446(HexTags.Items.EDIFIED_PLANKS)
            .method_10442("has_item", hasItem(HexTags.Items.EDIFIED_PLANKS)).method_10431(recipes);

        var enlightenment = HexAdvancements.ENLIGHTEN;
        class_2447.method_10437(class_7800.field_40636, HexBlocks.IMPETUS_EMPTY)
            .method_10434('B', class_1802.field_8076)
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            .method_10434('S', HexBlocks.SLATE_BLOCK)
            .method_10434('P', class_1802.field_20393)
            .method_10439("PSS")
            .method_10439("BAB")
            .method_10439("SSP")
            .method_10429("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40636, HexBlocks.EMPTY_DIRECTRIX)
            .method_10434('C', class_1802.field_8857)
            .method_10434('O', class_1802.field_8537)
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            .method_10434('S', HexBlocks.SLATE_BLOCK)
            .method_10439("CSS")
            .method_10439("OAO")
            .method_10439("SSC")
            .method_10429("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment)).method_10431(recipes);

        class_2447.method_10437(class_7800.field_40636, HexBlocks.AKASHIC_BOOKSHELF)
            .method_10433('L', HexTags.Items.EDIFIED_LOGS)
            .method_10433('P', HexTags.Items.EDIFIED_PLANKS)
            .method_10434('C', class_1802.field_8529)
            /*this is the*/.method_10439("LPL") // and what i have for you today is
            .method_10439("CCC")
            .method_10439("LPL")
            .method_10429("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment)).method_10431(recipes);

        class_2447.method_10436(class_7800.field_40636, HexBlocks.AKASHIC_LIGATURE, 4)
            .method_10433('L', HexTags.Items.EDIFIED_LOGS)
            .method_10433('P', HexTags.Items.EDIFIED_PLANKS)
            .method_10434('1', HexItems.AMETHYST_DUST)
            .method_10434('2', class_1802.field_27063)
            .method_10434('3', HexItems.CHARGED_AMETHYST)
            .method_10439("LPL")
            .method_10439("123")
            .method_10439("LPL")
            .method_10429("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment)).method_10431(recipes);

        // Stone sets
        stoneSet(recipes, HexBlocks.SLATE_BLOCK.method_8389(), HexBlocks.SLATE_BRICKS.method_8389(), HexBlocks.SLATE_BRICKS_SMALL.method_8389(), HexBlocks.SLATE_TILES.method_8389(), HexBlocks.SLATE_PILLAR.method_8389());
        stoneSet(recipes, class_2246.field_27159.method_8389(), HexBlocks.AMETHYST_BRICKS.method_8389(), HexBlocks.AMETHYST_BRICKS_SMALL.method_8389(), HexBlocks.AMETHYST_TILES.method_8389(), HexBlocks.AMETHYST_PILLAR.method_8389());
        stoneSet(recipes, HexBlocks.QUENCHED_ALLAY.method_8389(), HexBlocks.QUENCHED_ALLAY_BRICKS.method_8389(), HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.method_8389(), HexBlocks.QUENCHED_ALLAY_TILES.method_8389(), null);

        // Stone sets in stonecutter
        stoneCutterFromTag(recipes, HexTags.Items.SLATE_BLOCKS, HexBlocks.SLATE_BRICKS.method_8389(), HexBlocks.SLATE_BRICKS_SMALL.method_8389(), HexBlocks.SLATE_TILES.method_8389(), HexBlocks.SLATE_PILLAR.method_8389());
        stoneCutterFromTag(recipes, HexTags.Items.AMETHYST_BLOCKS, HexBlocks.AMETHYST_BRICKS.method_8389(), HexBlocks.AMETHYST_BRICKS_SMALL.method_8389(), HexBlocks.AMETHYST_TILES.method_8389(), HexBlocks.AMETHYST_PILLAR.method_8389());
        stoneCutterFromTag(recipes, HexTags.Items.QUENCHED_ALLAY_BLOCKS, HexBlocks.QUENCHED_ALLAY_BRICKS.method_8389(), HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.method_8389(), HexBlocks.QUENCHED_ALLAY_TILES.method_8389());

        // Slate & Amethyst block set
        class_2450.method_10448(class_7800.field_40634, HexBlocks.SLATE_AMETHYST_BRICKS.method_8389(), 2)
                .method_10454(HexBlocks.SLATE_BRICKS)
                .method_10454(HexBlocks.AMETHYST_BRICKS)
                .method_10442("has_item", method_10426(HexBlocks.SLATE)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40634, HexBlocks.SLATE_AMETHYST_BRICKS_SMALL.method_8389(), 2)
                .method_10454(HexBlocks.SLATE_BRICKS_SMALL)
                .method_10454(HexBlocks.AMETHYST_BRICKS_SMALL)
                .method_10442("has_item", method_10426(HexBlocks.SLATE)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40634, HexBlocks.SLATE_AMETHYST_TILES.method_8389(), 2)
                .method_10454(HexBlocks.SLATE_TILES)
                .method_10454(HexBlocks.AMETHYST_TILES)
                .method_10442("has_item", method_10426(HexBlocks.SLATE)).method_10431(recipes);

        class_2450.method_10448(class_7800.field_40634, HexBlocks.SLATE_AMETHYST_PILLAR.method_8389(), 2)
                .method_10454(HexBlocks.SLATE_PILLAR)
                .method_10454(HexBlocks.AMETHYST_PILLAR)
                .method_10442("has_item", method_10426(HexBlocks.SLATE)).method_10431(recipes);

        new BrainsweepRecipeBuilder(HexStateIngredients.of(class_2246.field_27159),
            new VillagerIngredient(null, null, 3),
            class_2246.field_27160.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("budding_amethyst"));

        new BrainsweepRecipeBuilder(HexStateIngredients.of(HexBlocks.IMPETUS_EMPTY),
            new VillagerIngredient(class_3852.field_17064, null, 2),
            HexBlocks.IMPETUS_RIGHTCLICK.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("impetus_rightclick"));

        new BrainsweepRecipeBuilder(HexStateIngredients.of(HexBlocks.IMPETUS_EMPTY),
            new VillagerIngredient(class_3852.field_17058, null, 2),
            HexBlocks.IMPETUS_LOOK.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("impetus_look"));

        new BrainsweepRecipeBuilder(HexStateIngredients.of(HexBlocks.IMPETUS_EMPTY),
            new VillagerIngredient(class_3852.field_17055, null, 2),
            HexBlocks.IMPETUS_REDSTONE.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("impetus_storedplayer"));

        new BrainsweepRecipeBuilder(HexStateIngredients.of(HexBlocks.EMPTY_DIRECTRIX),
            new VillagerIngredient(class_3852.field_17061, null, 1),
            HexBlocks.DIRECTRIX_REDSTONE.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("directrix_redstone"));

        new BrainsweepRecipeBuilder(HexStateIngredients.of(HexBlocks.EMPTY_DIRECTRIX),
                new VillagerIngredient(class_3852.field_17063, null, 1),
                HexBlocks.DIRECTRIX_BOOLEAN.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
                .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
                .method_17972(recipes, modLoc("directrix_boolean"));

        new BrainsweepRecipeBuilder(HexStateIngredients.of(HexBlocks.AKASHIC_LIGATURE),
            new VillagerIngredient(class_3852.field_17060, null, 5),
            HexBlocks.AKASHIC_RECORD.method_9564(), MediaConstants.CRYSTAL_UNIT * 10)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("akashic_record"));

        // Temporary tests
        new BrainsweepRecipeBuilder(HexStateIngredients.of(class_2246.field_27159),
            new EntityTypeIngredient(class_1299.field_38384),
            HexBlocks.QUENCHED_ALLAY.method_9564(), MediaConstants.CRYSTAL_UNIT)
            .method_33530("enlightenment", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, enlightenment))
            .method_17972(recipes, modLoc("quench_allay"));

        // Create compat; will need to be Neo only as Create 1.21 will not exist on Fabric
        /**
        this.conditions.apply(new CreateCrushingRecipeBuilder()
                .withInput(Blocks.AMETHYST_CLUSTER)
                .duration(150)
                .withOutput(Items.AMETHYST_SHARD, 7)
                .withOutput(HexItems.AMETHYST_DUST, 5)
                .withOutput(0.25f, HexItems.CHARGED_AMETHYST))
            .whenModLoaded("create")
            .save(recipes, ResourceLocation.fromNamespaceAndPath("create", "crushing/amethyst_cluster"));

        this.conditions.apply(new CreateCrushingRecipeBuilder()
                .withInput(Blocks.AMETHYST_BLOCK)
                .duration(150)
                .withOutput(Items.AMETHYST_SHARD, 3)
                .withOutput(0.5f, HexItems.AMETHYST_DUST, 4))
            .whenModLoaded("create")
            .save(recipes, ResourceLocation.fromNamespaceAndPath("create", "crushing/amethyst_block"));

        this.conditions.apply(new CreateCrushingRecipeBuilder()
                .withInput(Items.AMETHYST_SHARD)
                .duration(150)
                .withOutput(HexItems.AMETHYST_DUST, 4)
                .withOutput(0.5f, HexItems.AMETHYST_DUST))
            .whenModLoaded("create")
            .save(recipes, modLoc("compat/create/crushing/amethyst_shard"));
         */

        // FD compat
        for (var log : EDIFIED_LOGS) {
            this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                    .withInput(log)
                    .withTool(ingredients.axeStrip())
                    .withOutput(HexBlocks.STRIPPED_EDIFIED_LOG)
                    .withOutput("farmersdelight:tree_bark")
                    .withSound(class_3417.field_14675))
                .whenModLoaded("farmersdelight")
                .method_17972(recipes, modLoc("compat/farmersdelight/cutting/" + class_7923.field_41175.method_10221(log).method_12832()));
        }

        this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                .withInput(HexBlocks.EDIFIED_WOOD)
                .withTool(ingredients.axeStrip())
                .withOutput(HexBlocks.STRIPPED_EDIFIED_WOOD)
                .withOutput("farmersdelight:tree_bark")
                .withSound(class_3417.field_14675))
            .whenModLoaded("farmersdelight")
            .method_17972(recipes, modLoc("compat/farmersdelight/cutting/akashic_wood"));

        this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                .withInput(HexBlocks.EDIFIED_TRAPDOOR)
                .withTool(ingredients.axeDig())
                .withOutput(HexBlocks.EDIFIED_PLANKS))
            .whenModLoaded("farmersdelight")
            .method_17972(recipes, modLoc("compat/farmersdelight/cutting/akashic_trapdoor"));

        this.conditions.apply(new FarmersDelightCuttingRecipeBuilder()
                .withInput(HexBlocks.EDIFIED_DOOR)
                .withTool(ingredients.axeDig())
                .withOutput(HexBlocks.EDIFIED_PLANKS))
            .whenModLoaded("farmersdelight")
            .method_17972(recipes, modLoc("compat/farmersdelight/cutting/akashic_door"));
    }

    private void staffRecipe(class_8790 recipes, ItemStaff staff, class_1792 plank) {
        staffRecipe(recipes, staff, class_1856.method_8091(plank));
    }

    private void staffRecipe(class_8790 recipes, ItemStaff staff, class_1856 plank) {
        class_2447.method_10437(class_7800.field_40638, staff)
            .method_10428('W', plank)
            .method_10434('S', class_1802.field_8600)
            .method_10434('A', HexItems.CHARGED_AMETHYST)
            .method_10439(" SA")
            .method_10439(" WS")
            .method_10439("S  ")
            .method_10429("has_item", hasItem(HexItems.CHARGED_AMETHYST))
            .method_10431(recipes);
    }

    private void gayRecipe(class_8790 recipes, ItemPridePigment.Type type, class_1856 material) {
        var colorizer = HexItems.PRIDE_PIGMENTS.get(type);
        class_2447.method_10437(class_7800.field_40642, colorizer)
            .method_10434('D', HexItems.AMETHYST_DUST)
            .method_10428('C', material)
            .method_10439(" D ")
            .method_10439("DCD")
            .method_10439(" D ")
            .method_10429("has_item", hasItem(HexItems.AMETHYST_DUST))
            .method_10431(recipes);
    }

    private <T extends class_1860<?>> void specialRecipe(class_8790 consumer, class_1865<T> serializer, Function<class_7710, T> recipeFunc) {
        var name = class_7923.field_41189.method_10221(serializer);
        class_2456.method_10476(recipeFunc::apply).method_53820(consumer, HexAPI.MOD_ID + ":dynamic" + name.method_12832());
    }

    protected static class_175<class_2066.class_2068> hasItem(class_1935 itemLike) {
        return paucalInventoryTrigger(class_2073.class_2074.method_8973().method_8977(itemLike).method_8976());
    }

    protected static class_175<class_2066.class_2068> hasItem(class_6862<class_1792> itemLike) {
        return paucalInventoryTrigger(class_2073.class_2074.method_8973().method_8975(itemLike).method_8976());
    }

    /**
     * Prefixed with {@code paucal} to avoid collisions when Forge ATs {@link class_2446#method_53499}.
     */
    protected static class_175<class_2066.class_2068> paucalInventoryTrigger(class_2073... $$0) {

        return new class_175<>(
                class_174.field_1195,
                new class_2066.class_2068(Optional.empty(), class_2066.class_2068.class_8948.field_47265, List.of($$0))
        );
    }

    // ================================= From PAUCAL 1.20

    protected class_2447 ring(class_7800 category, class_1935 out, int count, class_1856 outer, @Nullable class_1856 inner) {
        return ringCornered(category, out, count, outer, outer, inner);
    }

    protected class_2447 ring(class_7800 category, class_1935 out, int count, class_1935 outer, @Nullable class_1935 inner) {
        return ring(category, out, count, class_1856.method_8091(outer), ingredientOf(inner));
    }

    protected class_2447 ring(class_7800 category, class_1935 out, int count, class_6862<class_1792> outer, @Nullable class_6862<class_1792> inner) {
        return ring(category, out, count, class_1856.method_8106(outer), ingredientOf(inner));
    }

    protected class_2447 ringCornerless(class_7800 category, class_1935 out, int count, class_1856 outer,
                                                 @Nullable class_1856 inner) {
        return ringCornered(category, out, count, outer, null, inner);
    }

    protected class_2447 ringCornerless(class_7800 category, class_1935 out, int count, class_1935 outer, @Nullable class_1935 inner) {
        return ringCornerless(category, out, count, class_1856.method_8091(outer), ingredientOf(inner));
    }

    protected class_2447 ringAll(class_7800 category, class_1935 out, int count, class_1856 outer, @Nullable class_1856 inner) {
        return ringCornered(category, out, count, outer, outer, inner);
    }

    protected class_2447 ringAll(class_7800 category, class_1935 out, int count, class_1935 outer, @Nullable class_1935 inner) {
        return ringAll(category, out, count, class_1856.method_8091(outer), ingredientOf(inner));
    }

    protected class_2447 ringCornered(class_7800 category, class_1935 out, int count, @Nullable class_1856 cardinal,
                                               @Nullable class_1856 diagonal, @Nullable class_1856 inner) {
        if (cardinal == null && diagonal == null && inner == null) {
            throw new IllegalArgumentException("at least one ingredient must be non-null");
        }
        if (inner != null && cardinal == null && diagonal == null) {
            throw new IllegalArgumentException("if inner is non-null, either cardinal or diagonal must not be");
        }

        var builder = class_2447.method_10436(category, out, count);
        var C = ' ';
        if (cardinal != null) {
            builder.method_10428('C', cardinal);
            C = 'C';
        }
        var D = ' ';
        if (diagonal != null) {
            builder.method_10428('D', diagonal);
            D = 'D';
        }
        var I = ' ';
        if (inner != null) {
            builder.method_10428('I', inner);
            I = 'I';
        }

        builder
                .method_10439(String.format("%c%c%c", D, C, D))
                .method_10439(String.format("%c%c%c", C, I, C))
                .method_10439(String.format("%c%c%c", D, C, D));

        return builder;
    }

    protected class_2447 stack(class_7800 category, class_1935 out, int count, class_1856 top, class_1856 bottom) {
        return class_2447.method_10436(category, out, count)
                .method_10428('T', top)
                .method_10428('B', bottom)
                .method_10439("T")
                .method_10439("B");
    }

    protected class_2447 stack(class_7800 category, class_1935 out, int count, class_1935 top, class_1935 bottom) {
        return stack(category, out, count, class_1856.method_8091(top), class_1856.method_8091(bottom));
    }

    protected class_2447 stack(class_7800 category, class_1935 out, int count, class_6862<class_1792> top, class_6862<class_1792> bottom) {
        return stack(category, out, count, class_1856.method_8106(top), class_1856.method_8106(bottom));
    }


    protected class_2447 stick(class_7800 category, class_1935 out, int count, class_1856 input) {
        return stack(category, out, count, input, input);
    }

    protected class_2447 stick(class_7800 category, class_1935 out, int count, class_1935 input) {
        return stick(category, out, count, class_1856.method_8091(input));
    }

    protected class_2447 stick(class_7800 category, class_1935 out, int count, class_6862<class_1792> input) {
        return stick(category, out, count, class_1856.method_8106(input));
    }

    /**
     * @param largeSize True for a 3x3, false for a 2x2
     */
    protected void packing(class_7800 category, class_1935 free, class_1935 compressed, String freeName, boolean largeSize, class_8790 recipes) {
        var pack = class_2447.method_10437(category, compressed)
                .method_10434('X', free);
        if (largeSize) {
            pack.method_10439("XXX").method_10439("XXX").method_10439("XXX");
        } else {
            pack.method_10439("XX").method_10439("XX");
        }
        pack.method_10429("has_item", hasItem(free)).method_17972(recipes, modLoc(freeName + "_packing"));

        class_2450.method_10448(category, free, largeSize ? 9 : 4)
                .method_10454(compressed)
                .method_10442("has_item", hasItem(free)).method_17972(recipes, modLoc(freeName + "_unpacking"));
    }

    @Nullable
    protected class_1856 ingredientOf(@Nullable class_1935 item) {
        return item == null ? null : class_1856.method_8091(item);
    }

    @Nullable
    protected class_1856 ingredientOf(@Nullable class_6862<class_1792> item) {
        return item == null ? null : class_1856.method_8106(item);
    }

    private void stoneSet(class_8790 recipes, class_1792 base, class_1792 bricks, class_1792 smallBricks, class_1792 tiles, @Nullable class_1792 pillar) {
        String smallBricksPath = class_7923.field_41178.method_10221(smallBricks).method_12832();
        String bricksPath = class_7923.field_41178.method_10221(bricks).method_12832();
        // Bricks from base block
        class_2447.method_10436(class_7800.field_40634, bricks, 4)
                .method_10434('#', base)
                .method_10439("##")
                .method_10439("##")
                .method_10429("has_item", hasItem(base))
                .method_10431(recipes);

        // Bricks from small bricks
        class_2450.method_10447(class_7800.field_40634, bricks)
                .method_10454(smallBricks)
                .method_10442("has_item", hasItem(base))
                .method_17972(recipes, modLoc(bricksPath + "_from_" + smallBricksPath));

        // Small bricks from bricks
        class_2450.method_10447(class_7800.field_40634, smallBricks)
                .method_10454(bricks)
                .method_10442("has_item", hasItem(base))
                .method_17972(recipes, modLoc(smallBricksPath + "_from_" + bricksPath));

        // Tiles from bricks
        class_2447.method_10436(class_7800.field_40634, tiles, 4)
                .method_10434('#', bricks)
                .method_10439("##")
                .method_10439("##")
                .method_10429("has_item", hasItem(base))
                .method_10431(recipes);

        // Pillar from base block
        if (pillar != null) {
            class_2447.method_10436(class_7800.field_40634, pillar, 2)
                    .method_10434('#', base)
                    .method_10439("#")
                    .method_10439("#")
                    .method_10429("has_item", hasItem(base))
                    .method_10431(recipes);
        }
    }

    private void stoneCutterFromTag(class_8790 recipes, class_6862<class_1792> tagKey, class_1792 ...results) {
        for (class_1792 result : results) {
            var resultPath = class_7923.field_41178.method_10221(result).method_12832();
            class_3981.method_17968(class_1856.method_8106(tagKey), class_7800.field_40634, result)
                    .method_17970("has_item", hasItem(tagKey))
                    .method_17972(recipes, modLoc("stonecutting/" + resultPath));
        }
    }
}
