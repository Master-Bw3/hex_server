package at.petrak.hexcasting.datagen.recipe.builders;

import com.google.common.collect.Lists;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5797;
import net.minecraft.class_8790;

public class FarmersDelightCuttingRecipeBuilder implements class_5797 {
    private String group = "";
    private final List<ProcessingOutput> outputs = Lists.newArrayList();
    private class_1856 input;
    private FarmersDelightToolIngredient toolAction;
    private class_3414 sound;

    @Override
    public FarmersDelightCuttingRecipeBuilder method_33530(String s, class_175<?> criterionTriggerInstance) {
        return this;
    }

    @Override
    public @NotNull FarmersDelightCuttingRecipeBuilder method_33529(@Nullable String name) {
        group = name;
        return this;
    }

    @Override
    public class_1792 method_36441() {
        return class_1802.field_8162; // Irrelevant, we implement serialization ourselves
    }

    public FarmersDelightCuttingRecipeBuilder withInput(class_1935 item) {
        return withInput(class_1856.method_8091(item));
    }

    public FarmersDelightCuttingRecipeBuilder withInput(class_1799 stack) {
        return withInput(class_1856.method_8101(stack));
    }

    public FarmersDelightCuttingRecipeBuilder withInput(class_1856 ingredient) {
        this.input = ingredient;
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(class_1935 output) {
        return withOutput(1f, output, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, class_1935 output) {
        return withOutput(chance, output, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(class_1935 output, int count) {
        return withOutput(1f, output, count);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, class_1935 output, int count) {
        return withOutput(new class_1799(output, count), chance);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(class_1799 output, float chance) {
        //this.outputs.add(new ItemProcessingOutput(output, chance));
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(String name) {
        return withOutput(1f, name, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(String name, int count) {
        return withOutput(1f, name, count);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, String name) {
        return withOutput(chance, name, 1);
    }

    public FarmersDelightCuttingRecipeBuilder withOutput(float chance, String name, int count) {
        this.outputs.add(new CompatProcessingOutput(name, count, chance));
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withTool(FarmersDelightToolIngredient ingredient) {
        this.toolAction = ingredient;
        return this;
    }

    public FarmersDelightCuttingRecipeBuilder withSound(class_3414 sound) {
        this.sound = sound;
        return this;
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_2960 id) {

    }
}
