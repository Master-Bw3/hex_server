package at.petrak.hexcasting.mixin;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_4095;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Nuke the brain at the source
@Mixin(class_1309.class)
public abstract class MixinLivingEntity {
    @Inject(method = "getBrain", at = @At("RETURN"))
    private void removeBrain(CallbackInfoReturnable<class_4095<?>> cir) {
        var self = (class_1309) (Object) this;
        if (self instanceof class_1308 mob && IXplatAbstractions.INSTANCE.isBrainswept(mob)) {
            var brain = cir.getReturnValue();
            brain.method_35060();
            cir.setReturnValue(brain);
        }
    }
}
