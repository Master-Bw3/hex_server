package at.petrak.hexcasting.mixin.accessor.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.Supplier;
import net.minecraft.class_776;
import net.minecraft.class_824;

@Mixin(class_824.class)
public interface AccessorBlockEntityRenderDispatcher {
    @Accessor("blockRenderDispatcher")
    Supplier<class_776> hex$getBlockRenderDispatcher();
}
