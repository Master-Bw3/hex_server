package at.petrak.hexcasting.mixin.accessor.client;

import net.minecraft.class_4668;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4668.class)
public interface AccessorRenderStateShard {
    @Accessor("name")
    String hex$name();
}
