package at.petrak.hexcasting.mixin.accessor.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

@Mixin(class_4668.class_5939.class)
public interface AccessorEmptyTextureStateShard {
    @Invoker("cutoutTexture")
    Optional<class_2960> hex$cutoutTexture();
}
