package at.petrak.hexcasting.mixin;

import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.loot.AddPerWorldPatternToScrollFunc;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_3902;
import net.minecraft.class_3989;
import net.minecraft.class_5819;
import net.minecraft.class_9306;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Adds ancient scrolls to the wandering trader by replacing the special trade in the last slot
@Mixin(class_3989.class)
public class MixinWanderingTrader {
	@Inject(method = "updateTrades", at = @At("RETURN"))
	private void addNewTrades(CallbackInfo ci) {
        var self = (class_3989) (Object) this;
        class_1916 offerList = self.method_8264();
        if (offerList == null)
            return;
        class_5819 rand = self.method_59922();
        if (rand.method_43057() < HexConfig.server().traderScrollChance() && self.method_5682() != null) {
            class_1799 scroll = new class_1799(HexItems.SCROLL_LARGE);
            AddPerWorldPatternToScrollFunc.doStatic(scroll, rand, self.method_5682().method_30002());
            scroll.method_57379(HexDataComponents.NEEDS_PURCHASE, class_3902.field_17274);
            offerList.set(5, new class_1914(new class_9306(class_1802.field_8687, 12), scroll, 1, 1, 1));
        }
    }
}
