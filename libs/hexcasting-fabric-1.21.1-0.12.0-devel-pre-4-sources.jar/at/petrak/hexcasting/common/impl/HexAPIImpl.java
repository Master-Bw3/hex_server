package at.petrak.hexcasting.common.impl;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3417;

public class HexAPIImpl implements HexAPI {
    private static final ConcurrentMap<class_1299<?>, EntityVelocityGetter<?>> SPECIAL_VELOCITIES
        = new ConcurrentHashMap<>();
    private static final ConcurrentMap<class_1299<?>, Consumer<?>> SPECIAL_BRAINSWEEPS
        = new ConcurrentHashMap<>();

    public <T extends class_1297> void registerSpecialVelocityGetter(class_1299<T> key,
        EntityVelocityGetter<T> getter) {
        if (SPECIAL_VELOCITIES.containsKey(key)) {
            HexAPI.LOGGER.warn("A special velocity getter was already registered to {}, clobbering it!",
                key.toString());
        }
        SPECIAL_VELOCITIES.put(key, getter);
    }

    @Override
    public class_243 getEntityVelocitySpecial(class_1297 entity) {
        class_1299<?> type = entity.method_5864();
        if (SPECIAL_VELOCITIES.containsKey(type)) {
            var velGetter = SPECIAL_VELOCITIES.get(type);
            var erasedGetter = (EntityVelocityGetter) velGetter;
            return erasedGetter.getVelocity(entity);
        }
        return entity.method_18798();
    }

    //region brainsweeping

    @Override
    public <T extends class_1308> void registerCustomBrainsweepingBehavior(class_1299<T> key, Consumer<T> hook) {
        if (SPECIAL_BRAINSWEEPS.containsKey(key)) {
            HexAPI.LOGGER.warn("A special brainsweep hook was already registered to {}, clobbering it!",
                key.toString());
        }
        SPECIAL_BRAINSWEEPS.put(key, hook);
    }

    @Override
    public <T extends class_1308> Consumer<T> getBrainsweepBehavior(class_1299<T> mobType) {
        var behavior = SPECIAL_BRAINSWEEPS.getOrDefault(mobType, this.defaultBrainsweepingBehavior());
        return (Consumer<T>) behavior;
    }

    @Override
    public Consumer<class_1308> defaultBrainsweepingBehavior() {
        return mob -> {
            mob.method_35056();

            // TODO: do we add this?
//            if (mob instanceof InventoryCarrier inv) {
//                inv.getInventory().removeAllItems().forEach(mob::spawnAtLocation);
//            }
        };
    }

    //endregion
    @Override
    public @Nullable Sentinel getSentinel(class_3222 player) {
        return IXplatAbstractions.INSTANCE.getSentinel(player);
    }

    @Override
    public @Nullable ADMediaHolder findMediaHolder(class_1799 stack) {
        return IXplatAbstractions.INSTANCE.findMediaHolder(stack);
    }

    @Override
    public FrozenPigment getColorizer(class_1657 player) {
        return IXplatAbstractions.INSTANCE.getPigment(player);
    }

    class_1741 ARMOR_MATERIAL = new class_1741(
            Collections.emptyMap(),
            0,
            class_3417.field_14581,
            () -> class_1856.field_9017,
            Collections.emptyList(), // TODO check textures. If not - use robes here from original code
            0,
            0
    );

    @Override
    public class_1741 robesMaterial() {
        return ARMOR_MATERIAL;
    }
}
