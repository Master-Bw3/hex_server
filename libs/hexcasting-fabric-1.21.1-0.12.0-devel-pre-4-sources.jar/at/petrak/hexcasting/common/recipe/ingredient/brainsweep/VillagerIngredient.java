package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import at.petrak.hexcasting.common.lib.HexBrainsweepeeIngredients;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Special case for villagers so we can have biome/profession/level reqs
 */
public class VillagerIngredient extends BrainsweepeeIngredient {
    public final @Nullable class_3852 profession;
    public final @Nullable class_3854 biome;
    public final int minLevel;

    public VillagerIngredient(
        @Nullable class_3852 profession,
        @Nullable class_3854 biome,
        int minLevel
    ) {
        this.profession = profession;
        this.biome = biome;
        this.minLevel = minLevel;
    }

    @Override
    public BrainsweepeeIngredientType<?> getType() {
        return HexBrainsweepeeIngredients.VILLAGER;
    }

    public @Nullable class_3852 getProfession() {
        return profession;
    }

    public @Nullable class_3854 getBiome() {
        return biome;
    }

    public int getMinLevel() {
        return minLevel;
    }

    @Override
    public boolean test(class_1297 entity, class_3218 level) {
        if (!(entity instanceof class_1646 villager)) return false;

        var data = villager.method_7231();

        return (this.profession == null || this.profession.equals(data.method_16924()))
            && (this.biome == null || this.biome.equals(data.method_16919()))
            && this.minLevel <= data.method_16925();
    }

    @Override
    public class_1297 exampleEntity(class_1937 level) {
        var biome = Objects.requireNonNullElse(this.biome, class_3854.field_17073);
        var profession = Objects.requireNonNullElse(this.profession, class_3852.field_17064);
        var tradeLevel = Math.min(this.minLevel, 1);

        var out = new class_1646(class_1299.field_6077, level);

        var data = out.method_7231();
        data
            .method_16921(profession)
            .method_16922(biome)
            .method_16920(tradeLevel);
        out.method_7195(data);

        // just random bullshit go to try and get it to update for god's sake
        var tag = new class_2487();
        out.method_5662(tag);

        return out;
    }

    @Override
    public List<class_2561> getTooltip(boolean advanced) {
        List<class_2561> tooltip = new ArrayList<>();
        tooltip.add(this.getName());

        if (advanced) {
            if (minLevel >= 5) {
                tooltip.add(class_2561.method_43469("hexcasting.tooltip.brainsweep.level", 5)
                    .method_27692(class_124.field_1063));
            } else if (minLevel > 1) {
                tooltip.add(class_2561.method_43469("hexcasting.tooltip.brainsweep.min_level", minLevel)
                    .method_27692(class_124.field_1063));
            }

            if (this.biome != null) {
                tooltip.add(class_2561.method_43470(this.biome.toString()).method_27692(class_124.field_1063));
            }

            if (this.profession != null) {
                tooltip.add(class_2561.method_43470(this.profession.toString()).method_27692(class_124.field_1063));
            }
        }

        tooltip.add(BrainsweepeeIngredient.getModNameComponent(
            this.profession == null
                ? "minecraft"
                : class_7923.field_41195.method_10221(this.profession).method_12836()));

        return tooltip;
    }

    @Override
    public String getSomeKindOfReasonableIDForEmi() {
        var bob = new StringBuilder();
        if (this.profession != null) {
            var profLoc = class_7923.field_41195.method_10221(this.profession);
            bob.append(profLoc.method_12836())
                    .append("//")
                    .append(profLoc.method_12832());
        } else {
            bob.append("null");
        }
        bob.append("_");
        if (this.biome != null) {
            var biomeLoc = class_7923.field_41194.method_10221(this.biome);
            bob.append(biomeLoc.method_12836())
                    .append("//")
                    .append(biomeLoc.method_12832());
        } else {
            bob.append("null");
        }

        bob.append(this.minLevel);
        return bob.toString();
    }

    @Override
    public class_2561 getName() {
        class_5250 component = class_2561.method_43470("");

        boolean addedAny = false;

        if (minLevel >= 5) {
            component.method_10852(class_2561.method_43471("merchant.level.5"));
            addedAny = true;
        } else if (minLevel > 1) {
            component.method_10852(class_2561.method_43471("merchant.level." + minLevel));
            addedAny = true;
        } else if (profession != null) {
            component.method_10852(class_2561.method_43471("merchant.level.1"));
            addedAny = true;
        }

        if (biome != null) {
            if (addedAny) {
                component.method_27693(" ");
            }
            var biomeLoc = class_7923.field_41194.method_10221(this.biome);
            component.method_10852(class_2561.method_43471("biome." + biomeLoc.method_12836() + "." + biomeLoc.method_12832()));
            addedAny = true;
        }

        if (profession != null) {
            // We've for sure added something
            component.method_27693(" ");
            var professionLoc = class_7923.field_41195.method_10221(this.profession);
            // TODO: what's the convention used for modded villager types?
            // Villager::getTypeName implies that it there's no namespace information.
            // i hope there is some convention
            component.method_10852(class_2561.method_43471("entity.minecraft.villager." + professionLoc.method_12832()));
        } else {
            if (addedAny) {
                component.method_27693(" ");
            }
            component.method_10852(class_1299.field_6077.method_5897());
        }

        return component;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VillagerIngredient that = (VillagerIngredient) o;
        return minLevel == that.minLevel && Objects.equals(profession, that.profession) && Objects.equals(biome,
            that.biome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(profession, biome, minLevel);
    }


    public static class Type implements BrainsweepeeIngredientType<VillagerIngredient> {
        public static final MapCodec<VillagerIngredient> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_7923.field_41195.method_39673().optionalFieldOf("profession").forGetter(ing -> Optional.ofNullable(ing.getProfession())),
                class_7923.field_41194.method_39673().optionalFieldOf("biome").forGetter(ing -> Optional.ofNullable(ing.getBiome())),
                Codec.INT.fieldOf("minLevel").forGetter(VillagerIngredient::getMinLevel)
        ).apply(instance, (a, b, c) -> new VillagerIngredient(a.orElse(null), b.orElse(null), c)));
        public static final class_9139<class_9129, VillagerIngredient> STREAM_CODEC = class_9139.method_56436(
                class_9135.method_56382(class_9135.method_56365(class_7924.field_41234)), ing -> Optional.ofNullable(ing.getProfession()),
                class_9135.method_56382(class_9135.method_56365(class_7924.field_41235)), ing -> Optional.ofNullable(ing.getBiome()),
                class_9135.field_48550, VillagerIngredient::getMinLevel,
                (a, b, c) -> new VillagerIngredient(a.orElse(null), b.orElse(null), c)
        );

        @Override
        public MapCodec<VillagerIngredient> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, VillagerIngredient> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
