package at.petrak.hexcasting.common.recipe.ingredient.state;

import at.petrak.hexcasting.common.lib.HexStateIngredients;
import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StateIngredientTag extends StateIngredientBlocks {
	private final class_6862<class_2248> tag;

	public StateIngredientTag(class_6862<class_2248> tag) {
		super(ImmutableSet.of());
		this.tag = tag;
	}

	@Override
	public StateIngredientType<?> getType() {
		return HexStateIngredients.TAG;
	}

	public Stream<class_2248> resolve() {
		return StreamSupport.stream(class_7923.field_41175.method_40286(tag).spliterator(), false)
			.map(class_6880::comp_349);
	}

	@Override
	public boolean test(class_2680 state) {
		return state.method_26164(tag);
	}

	@Override
	public class_2680 pick(Random random) {
		var values = resolve().toList();
		if (values.isEmpty()) {
			return null;
		}
		return values.get(random.nextInt(values.size())).method_9564();
	}

	@Override
	public List<class_1799> getDisplayedStacks() {
		return resolve()
			.filter(b -> b.method_8389() != class_1802.field_8162)
			.map(class_1799::new)
			.collect(Collectors.toList());
	}

	@Nonnull
	@Override
	protected List<class_2248> getBlocks() {
		return resolve().toList();
	}

	@Override
	public List<class_2680> getDisplayed() {
		return resolve().map(class_2248::method_9564).collect(Collectors.toList());
	}

	public class_6862<class_2248> getTag() {
		return tag;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		return tag.equals(((StateIngredientTag) o).tag);
	}

	@Override
	public int hashCode() {
		return tag.hashCode();
	}

	@Override
	public String toString() {
		return "StateIngredientTag{" + tag + "}";
	}


	public static class Type implements StateIngredientType<StateIngredientTag> {
		public static final MapCodec<StateIngredientTag> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
				class_6862.method_40093(class_7924.field_41254).fieldOf("tag").forGetter(StateIngredientTag::getTag)
		).apply(instance, StateIngredientTag::new));
		public static final class_9139<class_9129, StateIngredientTag> STREAM_CODEC = class_9139.method_56434(
				class_2960.field_48267.method_56432(id -> class_6862.method_40092(class_7924.field_41254, id), class_6862::comp_327), StateIngredientTag::getTag,
				StateIngredientTag::new
		);

		@Override
		public MapCodec<StateIngredientTag> codec() {
			return CODEC;
		}

		@Override
		public class_9139<class_9129, StateIngredientTag> streamCodec() {
			return STREAM_CODEC;
		}
	}
}
