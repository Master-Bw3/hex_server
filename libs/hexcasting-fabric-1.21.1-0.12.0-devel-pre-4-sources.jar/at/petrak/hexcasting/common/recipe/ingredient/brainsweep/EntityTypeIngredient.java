package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import at.petrak.hexcasting.common.lib.HexBrainsweepeeIngredients;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class EntityTypeIngredient extends BrainsweepeeIngredient {
    public final class_1299<?> entityType;

    public EntityTypeIngredient(class_1299<?> entityType) {
        this.entityType = entityType;
    }

    @Override
    public BrainsweepeeIngredientType<?> getType() {
        return HexBrainsweepeeIngredients.ENTITY_TYPE;
    }

    public class_1299<?> getEntityType() {
        return entityType;
    }

    @Override
    public boolean test(class_1297 entity, class_3218 level) {
        // entity types are singletons
        return entity.method_5864() == this.entityType;
    }

    @Override
    public class_2561 getName() {
        return this.entityType.method_5897();
    }

    @Override
    public List<class_2561> getTooltip(boolean advanced) {
        return List.of(
            this.entityType.method_5897(),
            BrainsweepeeIngredient.getModNameComponent(class_7923.field_41177.method_10221(this.entityType).method_12836())
        );
    }

    @Override
    public String getSomeKindOfReasonableIDForEmi() {
        var resloc = class_7923.field_41177.method_10221(this.entityType);
        return resloc.method_12836()
                + "//"
                + resloc.method_12832();
    }

    @Override
    public class_1297 exampleEntity(class_1937 level) {
        return this.entityType.method_5883(level);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityTypeIngredient that = (EntityTypeIngredient) o;
        return Objects.equals(entityType, that.entityType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(entityType);
    }


    public static class Type implements BrainsweepeeIngredientType<EntityTypeIngredient> {
        public static final MapCodec<EntityTypeIngredient> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_7923.field_41177.method_39673().fieldOf("entityType").forGetter(EntityTypeIngredient::getEntityType)
        ).apply(instance, EntityTypeIngredient::new));
        public static final class_9139<class_9129, EntityTypeIngredient> STREAM_CODEC = class_9139.method_56434(
                class_9135.method_56365(class_7924.field_41266), EntityTypeIngredient::getEntityType,
                EntityTypeIngredient::new
        );

        @Override
        public MapCodec<EntityTypeIngredient> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, EntityTypeIngredient> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
