package at.petrak.hexcasting.common.recipe.ingredient.state;


import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2680;

// https://github.com/VazkiiMods/Botania/blob/1.18.x/Common/src/main/java/vazkii/botania/api/recipe/StateIngredient.java
// good artists copy and all
public interface StateIngredient extends Predicate<class_2680> {

    StateIngredientType<?> getType();

    @Override
    boolean test(class_2680 state);

    class_2680 pick(Random random);

    List<class_1799> getDisplayedStacks();

    /**
     * A description tooltip to display in areas like JEI recipes.
     */
    default List<class_2561> descriptionTooltip() {
        return Collections.emptyList();
    }

    List<class_2680> getDisplayed();
}