package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3902;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemFocus extends class_1792 implements IotaHolderItem, VariantItem {
    // 0 = no overlay
    // 1 = unsealed
    // 2 = sealed
    public static final class_2960 OVERLAY_PRED = modLoc("overlay_layer");
    public static final class_2960 VARIANT_PRED = modLoc("variant");
    public static final int NUM_VARIANTS = 8;

    public ItemFocus(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public String method_7866(class_1799 stack) {
        return super.method_7866(stack) + (stack.method_57826(HexDataComponents.SEALED_IOTA_HOLDER) ? ".sealed" : "");
    }

    @Override
    public boolean writeable(class_1799 stack) {
        return !isSealed(stack);
    }

    @Override
    public boolean canWrite(class_1799 stack, Iota datum) {
        return datum == null || !isSealed(stack);
    }

    @Override
    public void writeDatum(class_1799 stack, Iota datum) {
        if (datum == null) {
            stack.method_57381(HexDataComponents.IOTA_HOLDER_IOTA);
            stack.method_57381(HexDataComponents.SEALED_IOTA_HOLDER);
        } else if (!isSealed(stack)) {
            stack.method_57379(HexDataComponents.IOTA_HOLDER_IOTA, datum);
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        IotaHolderItem.appendHoverText(this, stack, tooltipComponents, tooltipFlag);
    }

    public static boolean isSealed(class_1799 stack) {
        return stack.method_57826(HexDataComponents.SEALED_IOTA_HOLDER);
    }

    public static void seal(class_1799 stack) {
        stack.method_57379(HexDataComponents.SEALED_IOTA_HOLDER, class_3902.field_17274);
    }

    @Override
    public int numVariants() {
        return NUM_VARIANTS;
    }

    @Override
    public void setVariant(class_1799 stack, int variant) {
        if (!isSealed(stack))
            VariantItem.super.setVariant(stack, variant);
    }
}
