package at.petrak.hexcasting.common.items.magic;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class ItemMediaBattery extends ItemMediaHolder {
    public static final class_2960 MEDIA_PREDICATE = modLoc("media");
    public static final class_2960 MAX_MEDIA_PREDICATE = modLoc("max_media");

    public ItemMediaBattery(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public boolean canProvideMedia(class_1799 stack) {
        return true;
    }

    @Override
    public boolean canRecharge(class_1799 stack) {
        return true;
    }
}
