package at.petrak.hexcasting.common.blocks.akashic;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class BlockAkashicLigature extends class_2248 implements AkashicFloodfiller {
    public BlockAkashicLigature(class_2251 properties) {
        super(properties);
    }

    @Override
    public class_1269 use(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand, class_3965 pHit) {
        return null;
    }
}
