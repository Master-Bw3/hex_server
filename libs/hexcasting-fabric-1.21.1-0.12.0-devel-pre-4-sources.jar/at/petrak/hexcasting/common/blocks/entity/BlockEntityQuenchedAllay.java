package at.petrak.hexcasting.common.blocks.entity;

import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import java.util.function.BiFunction;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/**
 * No-op BE just to have a BER
 */
public class BlockEntityQuenchedAllay extends HexBlockEntity {
    public BlockEntityQuenchedAllay(BlockQuenchedAllay block, class_2338 pos, class_2680 blockState) {
        super(HexBlockEntities.typeForQuenchedAllay(block), pos, blockState);
    }

    public static BiFunction<class_2338, class_2680, BlockEntityQuenchedAllay> fromKnownBlock(BlockQuenchedAllay block) {
        return (pos, state) -> new BlockEntityQuenchedAllay(block, pos, state);
    }

    @Override
    protected void saveModData(class_2487 tag, class_7225.class_7874 registries) {

    }

    @Override
    protected void loadModData(class_2487 tag, class_7225.class_7874 registries) {

    }
}
