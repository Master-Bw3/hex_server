package at.petrak.hexcasting.common.blocks.circles.directrix;

import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3218;

public class BlockEmptyDirectrix extends BlockCircleComponent {
    // Technically the impetus only needs an axis, but all the datagen assumes it has a facing
    // so i might as well
    public static final class_2753 FACING = class_2741.field_12525;

    public BlockEmptyDirectrix(class_2251 p_49795_) {
        super(p_49795_);
        this.method_9590(this.field_10647.method_11664()
            .method_11657(ENERGIZED, false)
            .method_11657(FACING, class_2350.field_11043));
    }

    @Override
    public ControlFlow acceptControlFlow(CastingImage imageIn, CircleCastEnv env, class_2350 enterDir, class_2338 pos,
        class_2680 bs, class_3218 world) {
        var sign = world.field_9229.method_43056()
            ? bs.method_11654(FACING)
            : bs.method_11654(FACING).method_10153();
        return new ControlFlow.Continue(imageIn, List.of(this.exitPositionFromDirection(pos, sign)));
    }

    @Override
    public boolean canEnterFromDirection(class_2350 enterDir, class_2338 pos, class_2680 bs, class_3218 world) {
        // No entering from either of the output faces
        return enterDir != bs.method_11654(FACING).method_10153() && enterDir != bs.method_11654(FACING);
    }

    @Override
    public EnumSet<class_2350> possibleExitDirections(class_2338 pos, class_2680 bs, class_1937 world) {
        return EnumSet.of(bs.method_11654(FACING), bs.method_11654(FACING).method_10153());
    }

    @Override
    public class_2350 normalDir(class_2338 pos, class_2680 bs, class_1937 world, int recursionLeft) {
        return class_2350.field_11036;
    }

    @Override
    public float particleHeight(class_2338 pos, class_2680 bs, class_1937 world) {
        return 0.5f;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 pContext) {
        return BlockCircleComponent.placeStateDirAndSneak(this.method_9564(), pContext);
    }

    @Override
    public class_2680 method_9598(class_2680 pState, class_2470 pRot) {
        return pState.method_11657(FACING, pRot.method_10503(pState.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
        return pState.method_26186(pMirror.method_10345(pState.method_11654(FACING)));
    }
}
