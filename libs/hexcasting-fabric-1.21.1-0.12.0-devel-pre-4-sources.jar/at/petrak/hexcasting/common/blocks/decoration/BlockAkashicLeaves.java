package at.petrak.hexcasting.common.blocks.decoration;

import at.petrak.hexcasting.annotations.SoftImplement;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_2680;

public class BlockAkashicLeaves extends class_2397 {
    public BlockAkashicLeaves(class_2251 props) {
        super(props);
    }

    @SoftImplement("forge")
    public boolean isFlammable(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return true;
    }

    @SoftImplement("forge")
    public int getFlammability(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return 60;
    }

    @SoftImplement("forge")
    public int getFireSpreadSpeed(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return 30;
    }
}
