package at.petrak.hexcasting.common.blocks;

import at.petrak.hexcasting.annotations.SoftImplement;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

/**
 * Does absolutely nothing on Fabric; the flammable block registry is for that.
 */
public class BlockFlammable extends class_2248 {
    public final int burn, spread;

    public BlockFlammable(class_2251 $$0, int burn, int spread) {
        super($$0);
        this.burn = burn;
        this.spread = spread;
    }

    @SoftImplement("forge")
    public boolean isFlammable(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return true;
    }

    @SoftImplement("forge")
    public int getFlammability(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return burn;
    }

    @SoftImplement("forge")
    public int getFireSpreadSpeed(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return spread;
    }
}
