package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.common.blocks.BlockConjured;
import at.petrak.hexcasting.common.blocks.BlockConjuredLight;
import at.petrak.hexcasting.common.blocks.BlockFlammable;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicLigature;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicRecord;
import at.petrak.hexcasting.common.blocks.circles.BlockEmptyImpetus;
import at.petrak.hexcasting.common.blocks.circles.BlockSlate;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockBooleanDirectrix;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockEmptyDirectrix;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockRedstoneDirectrix;
import at.petrak.hexcasting.common.blocks.circles.impetuses.BlockLookingImpetus;
import at.petrak.hexcasting.common.blocks.circles.impetuses.BlockRedstoneImpetus;
import at.petrak.hexcasting.common.blocks.circles.impetuses.BlockRightClickImpetus;
import at.petrak.hexcasting.common.blocks.decoration.*;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5541;
import net.minecraft.class_8805;
import net.minecraft.class_8812;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexBlocks {
    public static void registerBlocks(BiConsumer<class_2248, class_2960> r) {
        for (var e : BLOCKS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    public static void registerBlockItems(BiConsumer<class_1792, class_2960> r) {
        for (var e : BLOCK_ITEMS.entrySet()) {
            r.accept(new class_1747(e.getValue().getFirst(), e.getValue().getSecond()), e.getKey());
        }
    }

    public static void registerBlockCreativeTab(Consumer<class_2248> r, class_1761 tab) {
        for (var block : BLOCK_TABS.getOrDefault(tab, List.of())) {
            r.accept(block);
        }
    }

    private static final Map<class_2960, class_2248> BLOCKS = new LinkedHashMap<>();
    private static final Map<class_2960, Pair<class_2248, class_1792.class_1793>> BLOCK_ITEMS = new LinkedHashMap<>();
    private static final Map<class_1761, List<class_2248>> BLOCK_TABS = new LinkedHashMap<>();


    private static class_4970.class_2251 slateish() {
        return class_4970.class_2251
            .method_9630(class_2246.field_28896)
            .method_9629(4f, 4f);
    }

    private static class_4970.class_2251 papery(class_3620 color) {
        return class_4970.class_2251
            .method_9637()
            .method_31710(color)
            .method_9626(class_2498.field_11535)
            .method_9618()
            .method_50013()
            .method_50012(class_3619.field_15971);
    }

    private static class_4970.class_2251 akashicWoodyHard() {
        return woodyHard(class_3620.field_16014);
    }

    private static class_4970.class_2251 woodyHard(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10431)
            .method_31710(color)
            .method_9626(class_2498.field_11547)
            .method_9629(3f, 4f);
    }

    private static class_4970.class_2251 edifiedWoody() {
        return woody(class_3620.field_16014);
    }

    private static class_4970.class_2251 woody(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10431)
            .method_31710(color)
            .method_9626(class_2498.field_11547)
            .method_9632(2f);
    }

    private static class_4970.class_2251 leaves(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10503)
            .method_9632(0.2F)
            .method_9640()
            .method_9626(class_2498.field_11535)
            .method_22488()
            .method_26235((bs, level, pos, type) -> type == class_1299.field_6081 || type == class_1299.field_6104)
            .method_26243(HexBlocks::never)
            .method_26245(HexBlocks::never);
    }

    // we have to make it emit light because otherwise it occludes itself and is always dark
    private static class_4970.class_2251 quenched() {
        return class_4970.class_2251
            .method_9630(class_2246.field_27159)
            .method_9631($ -> 4)
            .method_22488();
    }

    // we give these faux items so Patchi can have an item to view with
    public static final class_2248 CONJURED_LIGHT = blockItem("conjured_light",
        new BlockConjuredLight(
            class_4970.class_2251.method_9637()
                .method_31710(class_3620.field_16008)
                .method_9626(class_2498.field_27197)
                .method_9631((state) -> 15)
                .method_42327()
                .method_26235(HexBlocks::never)
                .method_9618()
                .method_50012(class_3619.field_15971)
                .method_9634()
                .method_26243(HexBlocks::never)
                .method_26245(HexBlocks::never)),
        new class_1792.class_1793());
    public static final class_2248 CONJURED_BLOCK = blockItem("conjured_block",
        new BlockConjured(
            class_4970.class_2251.method_9637()
                .method_31710(class_3620.field_16008)
                .method_9626(class_2498.field_27197)
                .method_9631((state) -> 2)
                .method_42327()
                .method_26235(HexBlocks::never)
                .method_9618()
                .method_22488()
                .method_26243(HexBlocks::never)
                .method_26245(HexBlocks::never)),
        new class_1792.class_1793());

    // "no" item because we add it manually
    public static final BlockSlate SLATE = blockNoItem("slate",
        new BlockSlate(slateish()
            .method_50012(class_3619.field_15971)));

    public static final BlockEmptyImpetus IMPETUS_EMPTY = blockItem("impetus/empty",
        new BlockEmptyImpetus(slateish()
            .method_50012(class_3619.field_15972)));
    public static final BlockRightClickImpetus IMPETUS_RIGHTCLICK = blockItem("impetus/rightclick",
        new BlockRightClickImpetus(slateish()
            .method_50012(class_3619.field_15972)
            .method_9631(bs -> bs.method_11654(BlockAbstractImpetus.ENERGIZED) ? 15 : 0)),
        HexItems.props().method_7894(class_1814.field_8907));
    public static final BlockLookingImpetus IMPETUS_LOOK = blockItem("impetus/look",
        new BlockLookingImpetus(slateish()
            .method_50012(class_3619.field_15972)
            .method_9631(bs -> bs.method_11654(BlockAbstractImpetus.ENERGIZED) ? 15 : 0)),
        HexItems.props().method_7894(class_1814.field_8907));
    public static final BlockRedstoneImpetus IMPETUS_REDSTONE = blockItem("impetus/redstone",
        new BlockRedstoneImpetus(slateish()
            .method_50012(class_3619.field_15972)
            .method_9631(bs -> bs.method_11654(BlockAbstractImpetus.ENERGIZED) ? 15 : 0)),
        HexItems.props().method_7894(class_1814.field_8907));


    public static final BlockEmptyDirectrix EMPTY_DIRECTRIX = blockItem("directrix/empty",
        new BlockEmptyDirectrix(slateish()
            .method_50012(class_3619.field_15972)));
    public static final BlockRedstoneDirectrix DIRECTRIX_REDSTONE = blockItem("directrix/redstone",
        new BlockRedstoneDirectrix(slateish()
            .method_50012(class_3619.field_15972)),
        HexItems.props().method_7894(class_1814.field_8907));
    public static final BlockBooleanDirectrix DIRECTRIX_BOOLEAN = blockItem("directrix/boolean",
        new BlockBooleanDirectrix(slateish()
            .method_50012(class_3619.field_15972)),
        HexItems.props().method_7894(class_1814.field_8907));

    public static final BlockAkashicRecord AKASHIC_RECORD = blockItem("akashic_record",
        new BlockAkashicRecord(akashicWoodyHard().method_9631(bs -> 15)),
        HexItems.props().method_7894(class_1814.field_8903)
    );
    public static final BlockAkashicBookshelf AKASHIC_BOOKSHELF = blockItem("akashic_bookshelf",
        new BlockAkashicBookshelf(akashicWoodyHard()
            .method_9631(bs -> (bs.method_11654(BlockAkashicBookshelf.HAS_BOOKS)) ? 4 : 0)));
    public static final BlockAkashicLigature AKASHIC_LIGATURE = blockItem("akashic_ligature",
        new BlockAkashicLigature(akashicWoodyHard().method_9631(bs -> 4)));

    public static final BlockQuenchedAllay QUENCHED_ALLAY = blockItem("quenched_allay", 
        new BlockQuenchedAllay(quenched()), 
        HexItems.props().method_7894(class_1814.field_8907)
    );

    // Decoration?!
    public static final BlockQuenchedAllay QUENCHED_ALLAY_TILES = blockItem("quenched_allay_tiles", new BlockQuenchedAllay(quenched()));
    public static final BlockQuenchedAllay QUENCHED_ALLAY_BRICKS = blockItem("quenched_allay_bricks", new BlockQuenchedAllay(quenched()));
    public static final BlockQuenchedAllay QUENCHED_ALLAY_BRICKS_SMALL = blockItem("quenched_allay_bricks_small", new BlockQuenchedAllay(quenched()));
    public static final class_2248 SLATE_BLOCK = blockItem("slate_block", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2248 SLATE_TILES = blockItem("slate_tiles", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2248 SLATE_BRICKS = blockItem("slate_bricks", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2248 SLATE_BRICKS_SMALL = blockItem("slate_bricks_small", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2465 SLATE_PILLAR = blockItem("slate_pillar", new class_2465(slateish().method_9629(2f, 4f)));
    public static final class_8812 AMETHYST_DUST_BLOCK = blockItem("amethyst_dust_block",
        new class_8812(new class_8805(0xb38ef3_ff), class_4970.class_2251.method_9630(class_2246.field_10102).method_31710(class_3620.field_16014)
            .method_9632(0.5f).method_9626(class_2498.field_11526)));
    public static final class_5541 AMETHYST_TILES = blockItem("amethyst_tiles",
        new class_5541(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final class_5541 AMETHYST_BRICKS = blockItem("amethyst_bricks",
            new class_5541(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final class_5541 AMETHYST_BRICKS_SMALL = blockItem("amethyst_bricks_small",
            new class_5541(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final BlockAmethystDirectional AMETHYST_PILLAR = blockItem("amethyst_pillar",
            new BlockAmethystDirectional(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final class_2248 SLATE_AMETHYST_TILES = blockItem("slate_amethyst_tiles", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2248 SLATE_AMETHYST_BRICKS = blockItem("slate_amethyst_bricks", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2248 SLATE_AMETHYST_BRICKS_SMALL = blockItem("slate_amethyst_bricks_small", new class_2248(slateish().method_9629(2f, 4f)));
    public static final class_2465 SLATE_AMETHYST_PILLAR = blockItem("slate_amethyst_pillar",
            new class_2465(slateish().method_9629(2f, 4f)));
    public static final class_2248 SCROLL_PAPER = blockItem("scroll_paper",
        new BlockFlammable(papery(class_3620.field_16003), 100, 60));
    public static final class_2248 ANCIENT_SCROLL_PAPER = blockItem("ancient_scroll_paper",
        new BlockFlammable(papery(class_3620.field_15981), 100, 60));
    public static final class_2248 SCROLL_PAPER_LANTERN = blockItem("scroll_paper_lantern",
        new BlockFlammable(papery(class_3620.field_16003).method_9631($ -> 15), 100, 60));
    public static final class_2248 ANCIENT_SCROLL_PAPER_LANTERN = blockItem(
        "ancient_scroll_paper_lantern",
        new BlockFlammable(papery(class_3620.field_15981).method_9631($ -> 12), 100, 60));
    public static final BlockSconce SCONCE = blockItem("amethyst_sconce",
        new BlockSconce(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_16014)
            .method_9626(class_2498.field_27197)
            .method_9632(1f)
            .method_9631($ -> 15))
        );

    public static final BlockAkashicLog EDIFIED_LOG = blockItem("edified_log",
        new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog EDIFIED_LOG_AMETHYST = blockItem("edified_log_amethyst",
            new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog EDIFIED_LOG_AVENTURINE = blockItem("edified_log_aventurine",
            new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog EDIFIED_LOG_CITRINE = blockItem("edified_log_citrine",
            new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog EDIFIED_LOG_PURPLE = blockItem("edified_log_purple",
            new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog STRIPPED_EDIFIED_LOG = blockItem("stripped_edified_log",
        new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog EDIFIED_WOOD = blockItem("edified_wood",
        new BlockAkashicLog(edifiedWoody()));
    public static final BlockAkashicLog STRIPPED_EDIFIED_WOOD = blockItem("stripped_edified_wood",
        new BlockAkashicLog(edifiedWoody()));
    public static final class_2248 EDIFIED_PLANKS = blockItem("edified_planks",
        new BlockFlammable(edifiedWoody(), 20, 5));
    public static final class_2248 EDIFIED_PANEL = blockItem("edified_panel",
        new BlockFlammable(edifiedWoody(), 20, 5));
    public static final class_2248 EDIFIED_TILE = blockItem("edified_tile",
        new BlockFlammable(edifiedWoody(), 20, 5));
    public static final class_2323 EDIFIED_DOOR = blockItem("edified_door",
        new BlockHexDoor(edifiedWoody().method_22488()));
    public static final class_2533 EDIFIED_TRAPDOOR = blockItem("edified_trapdoor",
        new BlockHexTrapdoor(edifiedWoody().method_22488()));
    public static final class_2510 EDIFIED_STAIRS = blockItem("edified_stairs",
        new BlockHexStairs(EDIFIED_PLANKS.method_9564(), edifiedWoody().method_22488()));

    public static final class_2354 EDIFIED_FENCE = blockItem("edified_fence",
            new BlockHexFence(edifiedWoody().method_22488()));
    public static final class_2349 EDIFIED_FENCE_GATE = blockItem("edified_fence_gate",
            new BlockHexFenceGate(edifiedWoody().method_22488()));

    public static final class_2482 EDIFIED_SLAB = blockItem("edified_slab",
        new BlockHexSlab(edifiedWoody().method_22488()));
    public static final class_2269 EDIFIED_BUTTON = blockItem("edified_button",
        new BlockHexWoodButton(edifiedWoody().method_22488().method_9634()));
    public static final class_2440 EDIFIED_PRESSURE_PLATE = blockItem("edified_pressure_plate",
        new BlockHexPressurePlate(edifiedWoody().method_22488().method_9634()));
    public static final BlockAkashicLeaves AMETHYST_EDIFIED_LEAVES = blockItem("amethyst_edified_leaves",
        new BlockAkashicLeaves(leaves(class_3620.field_16014)));
    public static final BlockAkashicLeaves AVENTURINE_EDIFIED_LEAVES = blockItem("aventurine_edified_leaves",
        new BlockAkashicLeaves(leaves(class_3620.field_15984)));
    public static final BlockAkashicLeaves CITRINE_EDIFIED_LEAVES = blockItem("citrine_edified_leaves",
        new BlockAkashicLeaves(leaves(class_3620.field_16010)));

    private static boolean never(Object... args) {
        return false;
    }

    private static <T extends class_2248> T blockNoItem(String name, T block) {
        var old = BLOCKS.put(modLoc(name), block);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        return block;
    }
    private static <T extends class_2248> T blockItem(String name, T block) {
        return blockItem(name, block, HexItems.props(), HexCreativeTabs.HEX);
    }

    private static <T extends class_2248> T blockItem(String name, T block, @Nullable class_1761 tab) {
        return blockItem(name, block, HexItems.props(), tab);
    }
    private static <T extends class_2248> T blockItem(String name, T block, class_1792.class_1793 props) {
        return blockItem(name, block, props, HexCreativeTabs.HEX);
    }

    private static <T extends class_2248> T blockItem(String name, T block, class_1792.class_1793 props, @Nullable class_1761 tab) {
        blockNoItem(name, block);
        var old = BLOCK_ITEMS.put(modLoc(name), new Pair<>(block, props));
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + name);
        }
        if (tab != null) {
            BLOCK_TABS.computeIfAbsent(tab, t -> new ArrayList<>()).add(block);
        }
        return block;
    }
}


