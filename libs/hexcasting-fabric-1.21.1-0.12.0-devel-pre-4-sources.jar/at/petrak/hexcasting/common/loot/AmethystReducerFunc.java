package at.petrak.hexcasting.common.loot;

import at.petrak.hexcasting.common.lib.HexLootFunctions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_120;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_47;
import net.minecraft.class_5339;
import net.minecraft.class_5341;

public class AmethystReducerFunc extends class_120 {
    public static final MapCodec<AmethystReducerFunc> CODEC = RecordCodecBuilder.mapCodec(
            codecInstance -> method_53344(codecInstance)
                    .and(
                            Codec.DOUBLE.fieldOf("delta").forGetter(AmethystReducerFunc::getDelta)
                    )
                    .apply(codecInstance, AmethystReducerFunc::new)
    );

    private final double delta;

    public AmethystReducerFunc(List<class_5341> lootItemConditions, double delta) {
        super(lootItemConditions);
        this.delta = delta;
    }

    public double getDelta() {
        return delta;
    }

    public static class_1799 doStatic(class_1799 stack, class_47 ctx, double amount) {
        if (stack.method_31574(class_1802.field_27063)) {
            stack.method_7939((int) (stack.method_7947() * (1 + amount)));
        }
        return stack;
    }

    @Override
    protected class_1799 method_522(class_1799 stack, class_47 ctx) {
        return doStatic(stack, ctx, this.delta);
    }

    @Override
    public class_5339<? extends class_120> method_29321() {
        return HexLootFunctions.AMETHYST_SHARD_REDUCER;
    }
}
