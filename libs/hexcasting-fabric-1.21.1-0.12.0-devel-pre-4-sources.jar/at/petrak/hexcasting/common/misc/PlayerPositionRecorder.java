package at.petrak.hexcasting.common.misc;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class PlayerPositionRecorder {
    private static final Map<class_1657, class_243> LAST_SECOND_POSITION_MAP = new WeakHashMap<>();
    private static final Map<class_1657, class_243> LAST_POSITION_MAP = new WeakHashMap<>();

    public static void updateAllPlayers(class_3218 world) {
        for (class_3222 player : world.method_18456()) {
            var prev = LAST_POSITION_MAP.get(player);
            if (prev != null)
                LAST_SECOND_POSITION_MAP.put(player, prev);
            LAST_POSITION_MAP.put(player, player.method_19538());
        }
    }

    public static class_243 getMotion(class_3222 player) {
        class_243 vec = LAST_POSITION_MAP.get(player);
        class_243 prev = LAST_SECOND_POSITION_MAP.get(player);

        if (vec == null)
            return class_243.field_1353;

        if (prev == null)
            return player.method_19538().method_1020(vec);

        return vec.method_1020(prev);
    }
}
