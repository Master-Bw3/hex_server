package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import net.minecraft.class_2960;
import net.minecraft.class_5632;

/**
 * Used for displaying patterns on the tooltips for scrolls and slates.
 *
 * @see at.petrak.hexcasting.client.gui.PatternTooltipComponent the client-side renderer for this
 */
public record PatternTooltip(HexPattern pattern, class_2960 background) implements class_5632 {
}
