package at.petrak.hexcasting.client.render.shader;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.mixin.accessor.client.AccessorRenderType;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

// https://github.com/VazkiiMods/Botania/blob/3a43accc2fbc439c9f2f00a698f8f8ad017503db/Common/src/main/java/vazkii/botania/client/core/helper/RenderHelper.java
public final class HexRenderTypes extends class_1921 {

    private HexRenderTypes(String string, class_293 vertexFormat, class_293.class_5596 mode, int i, boolean bl,
        boolean bl2, Runnable runnable, Runnable runnable2) {
        super(string, vertexFormat, mode, i, bl, bl2, runnable, runnable2);
        throw new UnsupportedOperationException("Should not be instantiated");
    }

    private static class_1921 makeLayer(String name, class_293 format, class_293.class_5596 mode,
        int bufSize, boolean hasCrumbling, boolean sortOnUpload, class_1921.class_4688 glState) {
        return AccessorRenderType.hex$create(name, format, mode, bufSize, hasCrumbling, sortOnUpload, glState);
    }

    private static final Function<class_2960, class_1921> GRAYSCALE_PROVIDER = class_156.method_34866(texture -> {
        class_4688 glState = class_1921.class_4688.method_23598()
            .method_34578(new class_5942(HexShaders::grayscale))
            .method_34577(new class_4683(texture, false, false))
            .method_23615(field_21364)
            .method_23603(field_21345)
            .method_23608(field_21383)
            .method_23611(field_21385)
            .method_23617(true);

        return makeLayer(HexAPI.MOD_ID + ":grayscale", class_290.field_1580, class_293.class_5596.field_27382, 256,
            true, false, glState);
    });

    public static class_1921 getGrayscaleLayer(class_2960 texture) {
        return GRAYSCALE_PROVIDER.apply(texture);
    }

}
