package at.petrak.hexcasting.client.render.shader;

import com.mojang.datafixers.util.Pair;
import java.io.IOException;
import java.util.function.Consumer;
import net.minecraft.class_290;
import net.minecraft.class_5912;
import net.minecraft.class_5944;

// https://github.com/VazkiiMods/Botania/blob/3a43accc2fbc439c9f2f00a698f8f8ad017503db/Common/src/main/java/vazkii/botania/client/core/helper/CoreShaders.java
public class HexShaders {
    private static class_5944 grayscale;

    public static void init(class_5912 resourceProvider,
                            Consumer<Pair<class_5944, Consumer<class_5944>>> registrations) throws IOException {
        registrations.accept(Pair.of(
            new class_5944(resourceProvider, "hexcasting__grayscale", class_290.field_1580),
            inst -> grayscale = inst)
        );
    }

    public static class_5944 grayscale() {
        return grayscale;
    }
}
