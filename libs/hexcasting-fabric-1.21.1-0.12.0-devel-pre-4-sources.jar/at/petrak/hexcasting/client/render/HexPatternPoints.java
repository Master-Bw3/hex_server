package at.petrak.hexcasting.client.render;

import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_241;

/**
 * static points making up a hex pattern to be rendered. It's used primarily for positioning, so we keep a
 * number of extra values here to avoid recomputing them.
 */
public class HexPatternPoints {
    public final ImmutableList<class_241> zappyPoints;
    public final ImmutableList<class_241> zappyPointsScaled;

    public final ImmutableList<class_241> dotsScaled;

    public final double rangeX;
    public final double rangeY;
    public final double finalScale;

    public final double fullWidth;
    public final double fullHeight;

    private double minX = Double.MAX_VALUE;
    private double minY = Double.MAX_VALUE;

    private final double offsetX;
    private final double offsetY;

    private static final ConcurrentMap<String, HexPatternPoints> CACHED_STATIC_POINTS = new ConcurrentHashMap<>();

    private HexPatternPoints(HexPatternLike patternlike, PatternSettings patSets, double seed) {

        List<class_241> dots = patternlike.getNonZappyPoints();

        // always do space calculations with the static version of the pattern
        // so that it doesn't jump around resizing itself.
        List<class_241> zappyPoints = RenderLib.makeZappy(dots, patternlike.getDups(),
                patSets.getHops(), patSets.getVariance(), 0f, patSets.getFlowIrregular(),
                patSets.getReadabilityOffset(), patSets.getLastSegmentProp(), seed);


        this.zappyPoints = ImmutableList.copyOf(zappyPoints);
        double maxY = Double.MIN_VALUE;
        double maxX = Double.MIN_VALUE;
        for (class_241 point : zappyPoints) {
            minX = Math.min(minX, point.field_1343);
            maxX = Math.max(maxX, point.field_1343);
            minY = Math.min(minY, point.field_1342);
            maxY = Math.max(maxY, point.field_1342);
        }
        rangeX = maxX - minX;
        rangeY = maxY - minY;

        // scales the patterns so that each point is patSets.baseScale units apart
        double baseScale = patSets.getBaseScale() / 1.5;

        // size of the pattern in pose space with no other adjustments
        double baseWidth = rangeX * baseScale;
        double baseHeight = rangeY * baseScale;

        // make sure that the scale fits within our min sizes
        double scale = Math.max(1.0, Math.max(
                (patSets.getMinWidth() - patSets.getStrokeWidthGuess()) / baseWidth,
                (patSets.getMinHeight() - patSets.getStrokeWidthGuess()) / baseHeight)
        );

        boolean vertFit = patSets.getVertAlignment().fit;
        boolean horFit = patSets.getHorAlignment().fit;

        // scale down if needed to fit in vertical space
        if(vertFit){
            scale = Math.min(scale, (patSets.getTargetHeight() - 2 * patSets.getVertPadding() - patSets.getStrokeWidthGuess())/(baseHeight));
        }

        // scale down if needed to fit in horizontal space
        if(horFit){
            scale = Math.min(scale, (patSets.getTargetWidth() - 2 * patSets.getHorPadding() - patSets.getStrokeWidthGuess())/(baseWidth));
        }

        finalScale = baseScale * scale;
        double finalStroke = patSets.getStrokeWidth(finalScale);

        double inherentWidth = (baseWidth * scale) + 2 * patSets.getHorPadding() + finalStroke;
        double inherentHeight = (baseHeight * scale) + 2 * patSets.getVertPadding() + finalStroke;

        // this is the amount of actual wiggle room we have for configurable position-ing.
        double widthDiff = Math.max(patSets.getTargetWidth() - inherentWidth, 0);
        double heightDiff = Math.max(patSets.getTargetHeight() - inherentHeight, 0);

        this.fullWidth = inherentWidth + widthDiff;
        this.fullHeight = inherentHeight + heightDiff;

        // center in inherent space and put extra space according to alignment stuff
        offsetX = ((inherentWidth - baseWidth * scale) / 2) + (widthDiff * patSets.getHorAlignment().amtInFront / 2);
        offsetY = ((inherentHeight - baseHeight * scale) / 2) + (heightDiff * patSets.getVertAlignment().amtInFront / 2);

        this.zappyPointsScaled = ImmutableList.copyOf(scaleVecs(zappyPoints));
        this.dotsScaled = ImmutableList.copyOf(scaleVecs(dots));
    }

    public class_241 scaleVec(class_241 point){
        return new class_241(
                (float) (((point.field_1343 - this.minX) * this.finalScale) + this.offsetX),
                (float) (((point.field_1342 - this.minY) * this.finalScale) + this.offsetY)
        );
    }

    public List<class_241> scaleVecs(List<class_241> points){
        List<class_241> scaledPoints = new ArrayList<>();
        for (class_241 point : points) {
            scaledPoints.add(scaleVec(point));
        }
        return scaledPoints;
    }


    /**
     * Gets the static points for the given pattern, settings, and seed. This is cached.
     *
     * This is used in rendering static patterns and positioning non-static patterns.
     *
     */
    public static HexPatternPoints getStaticPoints(HexPatternLike patternlike, PatternSettings patSets, double seed){

        String cacheKey = patSets.getCacheKey(patternlike, seed);

        return CACHED_STATIC_POINTS.computeIfAbsent(cacheKey, (key) -> new HexPatternPoints(patternlike, patSets, seed) );
    }
}