package at.petrak.hexcasting.client.render;

import at.petrak.hexcasting.api.client.ScryingLensOverlayRegistry;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.api.utils.QuaternionfUtils;
import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.lib.HexAttributes;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.datafixers.util.Pair;
import org.joml.Vector3f;

import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2477;
import net.minecraft.class_2583;
import net.minecraft.class_286;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_5348;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_9779;

public class HexAdditionalRenderers {
    public static void overlayLevel(class_4587 ps, float partialTick) {
        var player = class_310.method_1551().field_1724;
        if (player != null) {
            var sentinel = IXplatAbstractions.INSTANCE.getSentinel(player);
            if (sentinel != null && player.method_37908().method_27983().equals(sentinel.dimension())) {
                renderSentinel(sentinel, player, ps, partialTick);
            }
        }
    }

    public static void overlayGui(class_332 graphics, class_9779 partialTicks) {
        tryRenderScryingLensOverlay(graphics, partialTicks);
    }

    private static void renderSentinel(Sentinel sentinel, class_746 owner,
        class_4587 ps, float partialTicks) {
        ps.method_22903();

        // zero vector is the player
        var mc = class_310.method_1551();
        var camera = mc.field_1773.method_19418();
        var playerPos = camera.method_19326();
        ps.method_22904(
            sentinel.position().field_1352 - playerPos.field_1352,
            sentinel.position().field_1351 - playerPos.field_1351,
            sentinel.position().field_1350 - playerPos.field_1350);

        var time = ClientTickCounter.getTotal() / 2;
        var bobSpeed = 1f / 20;
        var magnitude = 0.1f;
        ps.method_46416(0, class_3532.method_15374(bobSpeed * time) * magnitude, 0);
        var spinSpeed = 1f / 30;
        ps.method_22907(QuaternionfUtils.fromXYZ(new Vector3f(0, spinSpeed * time, 0)));
        if (sentinel.extendsRange()) {
            ps.method_22907(QuaternionfUtils.fromXYZ(new Vector3f(spinSpeed * time / 8f, 0, 0)));
        }

        float scale = 0.5f;
        ps.method_22905(scale, scale, scale);


        var tess = class_289.method_1348();
        var neo = ps.method_23760().method_23761();
        RenderSystem.enableBlend();
        RenderSystem.setShader(class_757::method_34535);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.lineWidth(5f);

        var pigment = IXplatAbstractions.INSTANCE.getPigment(owner);
        var colProvider = pigment.getColorProvider();

        // Icosahedron inscribed inside the unit sphere
        var buf = tess.method_60827(class_293.class_5596.field_27377, class_290.field_29337);

        BiConsumer<float[], float[]> v = (l, r) -> {
            int lcolor = colProvider.getColor(time, new class_243(l[0], l[1], l[2])),
                rcolor = colProvider.getColor(time, new class_243(r[0], r[1], r[2]));
            var normal = new Vector3f(r[0] - l[0], r[1] - l[1], r[2] - l[2]);
            normal.normalize();
            buf.method_22918(neo, l[0], l[1], l[2])
                .method_39415(lcolor)
                .method_60831(ps.method_23760(), normal.x(), normal.y(), normal.z());
            buf.method_22918(neo, r[0], r[1], r[2])
                .method_39415(rcolor)
                .method_60831(ps.method_23760(), -normal.x(), -normal.y(), -normal.z());
        };

        for (int side = 0; side <= 1; side++) {
            var ring = (side == 0) ? Icos.BOTTOM_RING : Icos.TOP_RING;
            var apex = (side == 0) ? Icos.BOTTOM : Icos.TOP;

            // top & bottom spider
            for (int i = 0; i < 5; i++) {
                v.accept(apex, ring[i]);
            }

            // ring around
            for (int i = 0; i < 5; i++) {
                v.accept(ring[i % 5], ring[(i + 1) % 5]);
            }
        }
        // center band
        for (int i = 0; i < 5; i++) {
            var bottom = Icos.BOTTOM_RING[i];
            v.accept(Icos.TOP_RING[(i + 2) % 5], bottom);
            v.accept(bottom, Icos.TOP_RING[(i + 3) % 5]);
        }
        //tess.end();
        class_286.method_43433(buf.method_60800());
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        ps.method_22909();

    }

    private static class Icos {
        public static float[] TOP = {0, 1, 0};
        public static float[] BOTTOM = {0, -1, 0};
        public static float[][] TOP_RING = new float[5][];
        public static float[][] BOTTOM_RING = new float[5][];

        static {
            var theta = (float) class_3532.method_15349(0.5, 1);
            for (int i = 0; i < 5; i++) {
                var phi = (float) i / 5f * class_3532.field_29846;
                var x = class_3532.method_15362(theta) * class_3532.method_15362(phi);
                var y = class_3532.method_15374(theta);
                var z = class_3532.method_15362(theta) * class_3532.method_15374(phi);
                TOP_RING[i] = new float[]{x, y, z};
                BOTTOM_RING[i] = new float[]{-x, -y, -z};
            }
        }
    }

    private static void tryRenderScryingLensOverlay(class_332 graphics, class_9779 partialTicks) {
        var mc = class_310.method_1551();
        var ps = graphics.method_51448();

        class_746 player = mc.field_1724;
        class_638 level = mc.field_1687;
        if (player == null || level == null) {
            return;
        }

        if (player.method_45325(HexAttributes.SCRY_SIGHT) <= 0.0 || player.method_45325(HexAttributes.FEEBLE_MIND) > 0)
            return;

        var hitRes = mc.field_1765;
        if (hitRes != null && hitRes.method_17783() == class_239.class_240.field_1332) {
            var bhr = (class_3965) hitRes;
            var pos = bhr.method_17777();
            var bs = level.method_8320(pos);

            var lines = ScryingLensOverlayRegistry.getLines(bs, pos, player, level, bhr.method_17780());

            int totalHeight = 8;
            List<Pair<class_1799, List<class_5348>>> actualLines = Lists.newArrayList();

            var window = mc.method_22683();
            var maxWidth = (int) (window.method_4486() / 2f * 0.8f);

            for (var pair : lines) {
                totalHeight += mc.field_1772.field_2000 + 6;
                var text = pair.getSecond();
                var textLines = mc.field_1772.method_27527().method_27495(text, maxWidth, class_2583.field_24360);

                actualLines.add(Pair.of(pair.getFirst(), textLines));

                if (textLines.size() > 1) {
                    totalHeight += mc.field_1772.field_2000 * (textLines.size() - 1);
                }
            }

            if (!lines.isEmpty()) {
                var x = window.method_4486() / 2f + 8f;
                var y = window.method_4502() / 2f - totalHeight;
                ps.method_22903();
                ps.method_46416(x, y, 0);

                for (var pair : actualLines) {
                    var stack = pair.getFirst();
                    if (!stack.method_7960()) {
                        // this draws centered in the Y ...
                        graphics.method_51427(pair.getFirst(), 0, 0);
                    }
                    int tx = stack.method_7960() ? 0 : 18;
                    int ty = 5;
                    // but this draws where y=0 is the baseline
                    var text = pair.getSecond();

                    for (var line : text) {
                        var actualLine = class_2477.method_10517().method_30934(line);
                        graphics.method_35720(mc.field_1772, actualLine, tx, ty, 0xffffffff);
                        ps.method_46416(0, mc.field_1772.field_2000, 0);
                    }
                    if (text.isEmpty()) {
                        ps.method_46416(0, mc.field_1772.field_2000, 0);
                    }
                    ps.method_46416(0, 6, 0);
                }

                ps.method_22909();
            }
        }
    }
}
