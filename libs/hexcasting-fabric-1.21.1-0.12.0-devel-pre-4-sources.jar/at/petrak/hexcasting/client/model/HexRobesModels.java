package at.petrak.hexcasting.client.model;

import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.client.model.geom.builders.*;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexRobesModels {
    // This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into
    // this model's constructor
    public static final class_5601 LAYER_LOCATION = new class_5601(modLoc("robes"), "main");

    public static class_5607 variant1() {
        class_5609 meshdefinition = new class_5609();
        class_5610 partdefinition = meshdefinition.method_32111();

        class_5610 Hood = partdefinition.method_32117("Hood",
            class_5606.method_32108()
                .method_32101(0, 0).method_32098(-8.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, new class_5605(0.0F))
                .method_32101(0, 16).method_32098(-8.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, new class_5605(0.0F)),
            class_5603.method_32090(4.0F, -8.0F, -4.0F));

        class_5610 Horns = partdefinition.method_32117("Horns",
            class_5606.method_32108()
                .method_32101(24, 0).method_32098(-8.0F, 0.0F, 0.0F, 8.0F, 4.0F, 0.0F, new class_5605(0.0F))
                .method_32101(24, 0).method_32096().method_32098(9.5F, 0.0F, 0.0F, 8.0F, 4.0F, 0.0F, new class_5605(0.0F))
                .method_32106(false),
            class_5603.method_32090(-4.8F, -8.2F, 0.0F));

        class_5610 Torso = partdefinition.method_32117("Torso",
            class_5606.method_32108()
                .method_32101(40, 0).method_32098(-8.0F, 0.0F, 0.0F, 8.0F, 12.0F, 4.0F, new class_5605(0.0F))
                .method_32101(40, 16).method_32098(-8.0F, 0.0F, 0.0F, 8.0F, 12.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32090(4.0F, 0.0F, -2.0F));

        class_5610 Arms = partdefinition.method_32117("Arms",
            class_5606.method_32108()
                .method_32101(0, 32).method_32098(-4.0F, 0.0F, 0.0F, 4.0F, 12.0F, 4.0F, new class_5605(0.0F))
                .method_32101(0, 32).method_32096().method_32098(8.0F, 0.0F, 0.0F, 4.0F, 12.0F, 4.0F, new class_5605(0.0F))
                .method_32106(false),
            class_5603.method_32090(-4.0F, 0.0F, -2.0F));

        class_5610 Skirt = partdefinition.method_32117("Skirt", class_5606.method_32108(),
            class_5603.method_32090(0.0F, 12.0F, -2.0F));

        class_5610 Left_r1 = Skirt.method_32117("Left_r1",
            class_5606.method_32108()
                .method_32101(48, 32).method_32096().method_32098(0.1F, 0.0F, -4.0F, 4.0F, 12.0F, 4.0F, new class_5605(0.0F))
                .method_32106(false),
            class_5603.method_32091(0.0F, 0.0F, 4.0F, 0.0F, 0.0F, -0.1309F));

        class_5610 Right_r1 = Skirt.method_32117("Right_r1",
            class_5606.method_32108()
                .method_32101(48, 32).method_32098(-4.0F, 0.0F, -4.0F, 4.0F, 12.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.0F, 0.0F, 4.0F, 0.0F, 0.0F, 0.1309F));

        class_5610 Legs = partdefinition.method_32117("Legs",
            class_5606.method_32108().method_32101(16, 41)
                .method_32098(-4.0F, 0.0F, 0.0F, 4.0F, 3.0F, 4.0F, new class_5605(0.0F))
                .method_32101(16, 41).method_32098(0.0F, 0.0F, 0.0F, 4.0F, 3.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, 21.0F, -2.0F));

        return class_5607.method_32110(meshdefinition, 64, 64);
    }
}