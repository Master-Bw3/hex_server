package at.petrak.hexcasting.client.model;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1304;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5599;
import net.minecraft.class_563;
import net.minecraft.class_583;
import net.minecraft.class_742;
import net.minecraft.class_918;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class AltioraLayer<M extends class_583<class_742>> extends class_3887<class_742, M> {
    private static final class_2960 TEX_LOC = modLoc("textures/misc/altiora.png");

    private final class_563<class_742> elytraModel;

    public AltioraLayer(class_3883<class_742, M> renderer, class_5599 ems) {
        super(renderer);
        this.elytraModel = new class_563<>(ems.method_32072(HexModelLayers.ALTIORA));
    }

    @Override
    public void render(class_4587 ps, class_4597 buffer, int packedLight, class_742 player,
        float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw,
        float headPitch) {
        var altiora = IXplatAbstractions.INSTANCE.getAltiora(player);
        // do a best effort to not render over other elytra, although we can never patch up everything
        var chestSlot = player.method_6118(class_1304.field_6174);
        if (altiora != null && !chestSlot.method_31574(class_1802.field_8833)) {
            ps.method_22903();
            ps.method_22904(0.0, 0.0, 0.125);

            this.method_17165().method_17081(this.elytraModel);
            this.elytraModel.method_17079(player, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            class_4588 verts = class_918.method_27952(
                    buffer, class_1921.method_25448(TEX_LOC), true);
            // TODO port: check color
            this.elytraModel.method_2828(ps, verts, packedLight, class_4608.field_21444, -1);

            ps.method_22909();
        }
    }
}
