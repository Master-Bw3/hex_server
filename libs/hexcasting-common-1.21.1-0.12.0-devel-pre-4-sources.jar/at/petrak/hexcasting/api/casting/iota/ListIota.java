package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.casting.SpellList;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

import static java.lang.Math.max;

/**
 * This is a <i>wrapper</i> for {@link SpellList}.
 */
public class ListIota extends Iota {
    private SpellList list;
    private final int depth;
    private final int size;

    public ListIota(@NotNull SpellList list) {
        super(() -> HexIotaTypes.LIST);
        this.list = list;
        int maxChildDepth = 0;
        int totalSize = 1;
        for (Iota iota : list) {
            totalSize += iota.size();
            maxChildDepth = max(maxChildDepth, iota.depth());
        }
        depth = maxChildDepth + 1;
        size = totalSize;
    }

    public ListIota(@NotNull List<Iota> list) {
        this(new SpellList.LList(list));
    }

    public SpellList getList() {
        return list;
    }

    @Override
    public boolean isTruthy() {
        return this.getList().getNonEmpty();
    }

    @Override
    public boolean toleratesOther(Iota that) {
        if (!typesMatch(this, that)) {
            return false;
        }
        var a = this.getList();
        if (!(that instanceof ListIota list)) {
            return false;
        }
        var b = list.getList();

        SpellList.SpellListIterator aIter = a.iterator(), bIter = b.iterator();
        for (; ; ) {
            if (!aIter.hasNext() && !bIter.hasNext()) {
                // we ran out together!
                return true;
            }
            if (aIter.hasNext() != bIter.hasNext()) {
                // one remains full before the other
                return false;
            }
            Iota x = aIter.next(), y = bIter.next();
            if (!Iota.tolerates(x, y)) {
                return false;
            }
        }
    }

    @Override
    public @Nullable Iterable<Iota> subIotas() {
        return this.getList();
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public int depth() {
        return depth;
    }

    @Override
    public int hashCode() {
        return list.hashCode();
    }

    @Override
    public class_2561 display() {
        var out = class_2561.method_43473();

        for (int i = 0; i < list.size(); i++) {
            var sub = list.getAt(i);

            out.method_27693(sub.display());

            // only add a comma between 2 non-patterns (commas don't look good with Inline patterns)
            // TODO: maybe add a method on IotaType to allow it to opt out of commas?
            if (i < list.size() - 1) {
                var thisIotaNeedsComma = sub.type.get() != PatternIota.TYPE;
                var nextIotaNeedsComma = list.getAt(i + 1).type.get() != PatternIota.TYPE;
                var alwaysShowCommas = HexConfig.client() != null && HexConfig.client().alwaysShowListCommas();
                if (thisIotaNeedsComma || nextIotaNeedsComma || alwaysShowCommas)
                    out.method_27693(", ");
            }
        }
        return class_2561.method_43469("hexcasting.tooltip.list_contents", out).method_27692(class_124.field_1064);
    }

    public static IotaType<ListIota> TYPE = new IotaType<>() {

        public static final MapCodec<ListIota> CODEC = SpellList.getCODEC()
                .xmap(ListIota::new, ListIota::getList)
                .fieldOf("list");
        public static final class_9139<class_9129, ListIota> STREAM_CODEC =
                SpellList.getSTREAM_CODEC().map(ListIota::new, ListIota::getList);

        @Override
        public MapCodec<ListIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ListIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_aa00aa;
        }
    };
}
